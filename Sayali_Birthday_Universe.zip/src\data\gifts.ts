export interface GiftItem {
  id: number;
  boxNumber: string;
  ribbonColor: string;
  glowColor: string;
  title: string;
  subtitle: string;
  type: 'message' | 'photo' | 'memory' | 'reasons' | 'confetti-greeting' | 'grand-finale';
  content: {
    heading: string;
    subheading?: string;
    bodyText?: string;
    image?: string;
    caption?: string;
    reasons?: { icon: string; title: string; desc: string }[];
    badge?: string;
  };
}

export const giftsData: GiftItem[] = [
  {
    id: 1,
    boxNumber: "01",
    ribbonColor: "from-amber-400 to-yellow-600",
    glowColor: "rgba(255, 216, 138, 0.4)",
    title: "Celestial Whisper",
    subtitle: "A personal birthday message for my love",
    type: "message",
    content: {
      heading: "To The Light of My World",
      subheading: "A quiet message straight from my heart",
      bodyText: "Sayali, on your birthday, I want to thank you for simply being you. For the kindness that radiates in everything you touch, for your unwavering patience, and for the grace you carry every single day. Having you in my life makes every sunrise more promising and every night more serene. Happy Birthday, my dearest sweetheart.",
      badge: "Pure Love"
    }
  },
  {
    id: 2,
    boxNumber: "02",
    ribbonColor: "from-pink-400 to-rose-600",
    glowColor: "rgba(255, 130, 178, 0.4)",
    title: "Starlight Portrait",
    subtitle: "A favorite photograph inside a glowing frame",
    type: "photo",
    content: {
      heading: "Elegance Captured in Starlight",
      subheading: "A vision of poise, charm, and radiance",
      image: "/images/memories/sayali_glamour.jpg",
      caption: "This photograph captures not just your stunning beauty, but that gentle, quiet confidence that makes you so breathtakingly unique.",
      badge: "Favorite Portrait"
    }
  },
  {
    id: 3,
    boxNumber: "03",
    ribbonColor: "from-purple-400 to-indigo-600",
    glowColor: "rgba(165, 107, 255, 0.4)",
    title: "Golden Keepsake",
    subtitle: "A special memory with a treasured caption",
    type: "memory",
    content: {
      heading: "Adorned in Joy & Togetherness",
      subheading: "[Editable Milestone: Our Festive Harmony]",
      image: "/images/memories/couple_traditional.jpg",
      caption: "When both of us stood together in traditional yellow, sharing laughter and prayers for our future, I knew we were built for a lifetime of happiness.",
      bodyText: "Every tradition feels deeper, and every festivity feels richer when I get to celebrate it holding your hand.",
      badge: "Golden Keepsake"
    }
  },
  {
    id: 4,
    boxNumber: "04",
    ribbonColor: "from-cyan-400 to-blue-600",
    glowColor: "rgba(56, 189, 248, 0.4)",
    title: "Galaxy of Smiles",
    subtitle: "Reasons you make my world brighter",
    type: "reasons",
    content: {
      heading: "Why You Make My Universe Smile",
      subheading: "Just a few of the million things I adore about you",
      reasons: [
        {
          icon: "Sparkles",
          title: "Your Radiant Smile",
          desc: "The way your face lights up can effortlessly dissolve any stress after a long day."
        },
        {
          icon: "Heart",
          title: "Your Genuine Empathy",
          desc: "You care deeply for everyone around you and bring genuine warmth to our home."
        },
        {
          icon: "Sun",
          title: "Your Playful Spirit",
          desc: "Your cute laughter, teasing jokes, and cheerful energy make every day an adventure."
        },
        {
          icon: "Shield",
          title: "My Safest Haven",
          desc: "No matter how turbulent the world outside is, in your arms is where I find total peace."
        }
      ],
      badge: "Infinite Reasons"
    }
  },
  {
    id: 5,
    boxNumber: "05",
    ribbonColor: "from-rose-400 to-purple-600",
    glowColor: "rgba(244, 63, 94, 0.4)",
    title: "Cosmic Confetti",
    subtitle: "An animated celebration greeting",
    type: "confetti-greeting",
    content: {
      heading: "A Universe of Joy for You!",
      subheading: "Celebrate, shine, and let happiness burst!",
      bodyText: "Here is to another trip around the sun for the most gorgeous soul! May this year bring you the sweetest surprises, good health, boundless success, and endless moments of pure bliss.",
      badge: "Celebration Alert"
    }
  },
  {
    id: 6,
    boxNumber: "06",
    ribbonColor: "from-amber-300 via-pink-400 to-purple-500",
    glowColor: "rgba(255, 216, 138, 0.6)",
    title: "The Grand Cosmic Gift",
    subtitle: "A personal photograph, loving vow & universe reveal",
    type: "grand-finale",
    content: {
      heading: "My Universe, Today & For All Eternity",
      subheading: "Our love story shining through all space and time",
      image: "/images/memories/sayali_hero.jpg",
      caption: "You are my star, my calm harbor, and my forever adventure.",
      bodyText: "Sayali, every gift on this website is just a small reflection of the endless love I hold for you. No matter where life leads us, my promise to you is to cherish you, laugh with you, support you, and love you more and more every single day. Happy Birthday, my Queen!",
      badge: "The Grand Finale"
    }
  }
];
