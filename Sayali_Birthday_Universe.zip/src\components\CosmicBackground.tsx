import React, { useEffect, useRef } from 'react';

export const CosmicBackground: React.FC = () => {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let animationFrameId: number;
    let width = (canvas.width = window.innerWidth);
    let height = (canvas.height = window.innerHeight);

    const handleResize = () => {
      if (!canvas) return;
      width = canvas.width = window.innerWidth;
      height = canvas.height = window.innerHeight;
    };

    window.addEventListener('resize', handleResize);

    // Star types: twinkling, colored stars, drifting dust
    interface Star {
      x: number;
      y: number;
      size: number;
      baseAlpha: number;
      alpha: number;
      twinkleSpeed: number;
      color: string;
      speedX: number;
      speedY: number;
    }

    const starColors = [
      '#FFFFFF', // pure white
      '#FFD88A', // champagne gold
      '#FF82B2', // romantic pink
      '#A56BFF', // nebula violet
      '#D0E2FF', // diamond blue
    ];

    const starCount = Math.min(180, Math.floor((width * height) / 8000));
    const stars: Star[] = [];

    for (let i = 0; i < starCount; i++) {
      const baseAlpha = Math.random() * 0.7 + 0.3;
      stars.push({
        x: Math.random() * width,
        y: Math.random() * height,
        size: Math.random() * 1.8 + 0.4,
        baseAlpha,
        alpha: baseAlpha,
        twinkleSpeed: Math.random() * 0.03 + 0.008,
        color: starColors[Math.floor(Math.random() * starColors.length)],
        speedX: (Math.random() - 0.5) * 0.08,
        speedY: (Math.random() - 0.5) * 0.08,
      });
    }

    // Shooting stars
    interface ShootingStar {
      x: number;
      y: number;
      length: number;
      speed: number;
      angle: number;
      opacity: number;
      active: boolean;
    }

    let shootingStar: ShootingStar = {
      x: 0,
      y: 0,
      length: 0,
      speed: 0,
      angle: Math.PI / 4,
      opacity: 0,
      active: false,
    };

    const triggerShootingStar = () => {
      shootingStar = {
        x: Math.random() * (width * 0.8) + width * 0.1,
        y: Math.random() * (height * 0.4),
        length: Math.random() * 80 + 70,
        speed: Math.random() * 12 + 16,
        angle: (Math.PI / 4) + (Math.random() - 0.5) * 0.3,
        opacity: 1,
        active: true,
      };
    };

    let shootingStarTimer = 0;

    // Render loop
    let time = 0;
    const render = () => {
      time += 0.01;
      ctx.clearRect(0, 0, width, height);

      // Draw faint deep space dust
      stars.forEach((star) => {
        star.alpha = star.baseAlpha + Math.sin(time * star.twinkleSpeed * 100) * 0.25;
        if (star.alpha < 0.1) star.alpha = 0.1;

        star.x += star.speedX;
        star.y += star.speedY;

        if (star.x < 0) star.x = width;
        if (star.x > width) star.x = 0;
        if (star.y < 0) star.y = height;
        if (star.y > height) star.y = 0;

        ctx.fillStyle = star.color;
        ctx.globalAlpha = Math.max(0.1, Math.min(1, star.alpha));
        ctx.beginPath();
        ctx.arc(star.x, star.y, star.size, 0, Math.PI * 2);
        ctx.fill();

        // Subtle glow for larger stars
        if (star.size > 1.4) {
          ctx.beginPath();
          ctx.arc(star.x, star.y, star.size * 2.5, 0, Math.PI * 2);
          ctx.fillStyle = star.color;
          ctx.globalAlpha = star.alpha * 0.25;
          ctx.fill();
        }
      });

      // Handle shooting stars
      shootingStarTimer++;
      if (shootingStarTimer > 320 && Math.random() < 0.03 && !shootingStar.active) {
        triggerShootingStar();
        shootingStarTimer = 0;
      }

      if (shootingStar.active) {
        ctx.save();
        ctx.globalAlpha = shootingStar.opacity;
        ctx.strokeStyle = 'rgba(255, 235, 180, 0.9)';
        ctx.lineWidth = 1.8;
        ctx.lineCap = 'round';

        const tailX = shootingStar.x - Math.cos(shootingStar.angle) * shootingStar.length;
        const tailY = shootingStar.y - Math.sin(shootingStar.angle) * shootingStar.length;

        const grad = ctx.createLinearGradient(tailX, tailY, shootingStar.x, shootingStar.y);
        grad.addColorStop(0, 'rgba(255, 216, 138, 0)');
        grad.addColorStop(0.7, 'rgba(255, 130, 178, 0.6)');
        grad.addColorStop(1, 'rgba(255, 255, 255, 1)');

        ctx.strokeStyle = grad;
        ctx.beginPath();
        ctx.moveTo(tailX, tailY);
        ctx.lineTo(shootingStar.x, shootingStar.y);
        ctx.stroke();

        shootingStar.x += Math.cos(shootingStar.angle) * shootingStar.speed;
        shootingStar.y += Math.sin(shootingStar.angle) * shootingStar.speed;
        shootingStar.opacity -= 0.022;

        if (shootingStar.opacity <= 0 || shootingStar.x > width || shootingStar.y > height) {
          shootingStar.active = false;
        }
        ctx.restore();
      }

      animationFrameId = requestAnimationFrame(render);
    };

    render();

    return () => {
      window.removeEventListener('resize', handleResize);
      cancelAnimationFrame(animationFrameId);
    };
  }, []);

  return (
    <div className="fixed inset-0 pointer-events-none z-0 overflow-hidden" aria-hidden="true">
      {/* Deep cosmic gradient base */}
      <div className="absolute inset-0 bg-radial-gradient from-[#0D1230] via-[#050510] to-[#020207] opacity-95" />

      {/* Layered nebulas */}
      <div 
        className="absolute -top-[20%] -left-[10%] w-[65vw] h-[65vw] rounded-full bg-gradient-to-br from-cosmic-purple/20 via-cosmic-violet/10 to-transparent blur-[120px] animate-nebula pointer-events-none" 
      />
      <div 
        className="absolute top-[35%] -right-[15%] w-[60vw] h-[60vw] rounded-full bg-gradient-to-bl from-cosmic-pink/15 via-purple-900/10 to-transparent blur-[130px] animate-nebula pointer-events-none" 
        style={{ animationDelay: '4s' }}
      />
      <div 
        className="absolute -bottom-[20%] left-[20%] w-[55vw] h-[55vw] rounded-full bg-gradient-to-t from-cosmic-navy/40 via-cosmic-purple/15 to-transparent blur-[140px] animate-nebula pointer-events-none" 
        style={{ animationDelay: '8s' }}
      />

      {/* Canvas for starfield & shooting stars */}
      <canvas ref={canvasRef} className="absolute inset-0 w-full h-full block" />
    </div>
  );
};
