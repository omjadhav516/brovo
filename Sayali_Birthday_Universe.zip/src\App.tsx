import React, { useEffect } from 'react';
import { HashRouter as Router, Routes, Route, useLocation } from 'react-router-dom';
import { CosmicBackground } from './components/CosmicBackground';
import { Navbar } from './components/Navbar';
import { Footer } from './components/Footer';

// Pages
import { Home } from './pages/Home';
import { LoveStory } from './pages/LoveStory';
import { MemoryGalaxy } from './pages/MemoryGalaxy';
import { LoveLetter } from './pages/LoveLetter';
import { GiftRoom } from './pages/GiftRoom';
import { SpecialMoments } from './pages/SpecialMoments';
import { Finale } from './pages/Finale';
import { NotFound } from './pages/NotFound';

// Automatically scroll to top on route navigation
const ScrollToTop: React.FC = () => {
  const { pathname } = useLocation();
  useEffect(() => {
    window.scrollTo(0, 0);
  }, [pathname]);
  return null;
};

export const App: React.FC = () => {
  return (
    <Router>
      <ScrollToTop />
      <div className="relative min-h-screen bg-cosmic-black text-cosmic-white flex flex-col font-sans selection:bg-cosmic-pink selection:text-white">
        {/* Dynamic canvas starfield & nebula background */}
        <CosmicBackground />

        {/* Global sticky navigation bar */}
        <Navbar />

        {/* Dynamic Page Routes */}
        <main className="flex-1 relative z-10">
          <Routes>
            <Route path="/" element={<Home />} />
            <Route path="/story" element={<LoveStory />} />
            <Route path="/gallery" element={<MemoryGalaxy />} />
            <Route path="/letter" element={<LoveLetter />} />
            <Route path="/gifts" element={<GiftRoom />} />
            <Route path="/moments" element={<SpecialMoments />} />
            <Route path="/finale" element={<Finale />} />
            <Route path="*" element={<NotFound />} />
          </Routes>
        </main>

        {/* Global Footer */}
        <Footer />
      </div>
    </Router>
  );
};

export default App;
