import React from 'react';
import { Sparkles } from 'lucide-react';

interface PageHeaderProps {
  badge: string;
  title: string;
  subtitle: string;
  center?: boolean;
}

export const PageHeader: React.FC<PageHeaderProps> = ({
  badge,
  title,
  subtitle,
  center = true
}) => {
  return (
    <div className={`mb-10 sm:mb-14 ${center ? 'text-center' : 'text-left'}`}>
      {/* Glowing tag badge */}
      <div className={`inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-medium tracking-wide uppercase bg-cosmic-purple/30 border border-cosmic-violet/40 text-cosmic-gold mb-3 shadow-glow-violet/20 ${center ? 'mx-auto' : ''}`}>
        <Sparkles size={12} className="text-cosmic-pink animate-pulse" />
        <span>{badge}</span>
      </div>

      {/* Main Title */}
      <h1 className="text-3xl sm:text-4xl md:text-5xl font-serif font-bold text-gradient-cosmic tracking-tight mb-3">
        {title}
      </h1>

      {/* Subtitle */}
      <p className="text-sm sm:text-base md:text-lg text-purple-200/80 max-w-2xl mx-auto font-light leading-relaxed">
        {subtitle}
      </p>

      {/* Decorative divider line */}
      <div className="flex items-center justify-center gap-3 mt-5">
        <div className="h-[1px] w-12 bg-gradient-to-r from-transparent to-cosmic-gold/40" />
        <div className="w-1.5 h-1.5 rounded-full bg-cosmic-gold shadow-glow-gold" />
        <div className="h-[1px] w-12 bg-gradient-to-l from-transparent to-cosmic-gold/40" />
      </div>
    </div>
  );
};
