import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { 
  Sparkles, 
  Calendar, 
  Eye, 
  Heart, 
  ArrowRight, 
  Filter, 
  Layers
} from 'lucide-react';
import { memoriesData, memoryCategories, MemoryItem } from '../data/memories';
import { PageHeader } from '../components/PageHeader';
import { Lightbox } from '../components/Lightbox';
import { FairyLights } from '../components/FairyLights';
import { ConstellationCanvas } from '../components/ConstellationCanvas';

export const MemoryGalaxy: React.FC = () => {
  const [selectedCategory, setSelectedCategory] = useState<string>('All');
  const [lightboxOpen, setLightboxOpen] = useState<boolean>(false);
  const [activePhotoIndex, setActivePhotoIndex] = useState<number>(0);

  const filteredMemories = selectedCategory === 'All'
    ? memoriesData
    : memoriesData.filter(m => m.category === selectedCategory);

  const openLightbox = (index: number) => {
    setActivePhotoIndex(index);
    setLightboxOpen(true);
  };

  const nextPhoto = () => {
    setActivePhotoIndex((prev) => (prev + 1) % filteredMemories.length);
  };

  const prevPhoto = () => {
    setActivePhotoIndex((prev) => (prev - 1 + filteredMemories.length) % filteredMemories.length);
  };

  return (
    <div className="relative min-h-screen py-10 px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto">
      <ConstellationCanvas dotCount={35} connectDistance={100} />
      <FairyLights curve="arch" bulbCount={16} />

      <PageHeader
        badge="Constellations of Memories"
        title="Our Memory Galaxy"
        subtitle="A sacred galaxy dedicated to the real smiles, festive memories, warm hugs, and quiet walks we hold dearest to our hearts."
      />

      {/* Category Filter Pills */}
      <div className="flex items-center justify-start md:justify-center gap-2 overflow-x-auto pb-4 mb-10 scrollbar-none">
        {memoryCategories.map((cat) => (
          <button
            key={cat}
            onClick={() => setSelectedCategory(cat)}
            className={`px-4 py-2 rounded-full text-xs font-medium whitespace-nowrap transition-all duration-300 flex items-center gap-1.5 ${
              selectedCategory === cat
                ? 'bg-gradient-to-r from-cosmic-purple to-cosmic-pink text-white shadow-glow-pink border border-cosmic-pink/50 font-semibold'
                : 'bg-cosmic-navy/70 text-purple-300/80 hover:text-white border border-cosmic-violet/20 hover:border-cosmic-violet/50'
            }`}
          >
            {cat === 'All' ? <Layers size={13} /> : <Sparkles size={13} className="text-cosmic-gold" />}
            <span>{cat}</span>
          </button>
        ))}
      </div>

      {/* Responsive Photo Galaxy Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6 sm:gap-8">
        {filteredMemories.map((memory, index) => (
          <div
            key={memory.id}
            onClick={() => openLightbox(index)}
            className="group relative cursor-pointer glass-panel p-3 sm:p-4 rounded-3xl border border-cosmic-violet/30 hover:border-cosmic-pink/60 transition-all duration-500 hover:-translate-y-2 hover:shadow-[0_15px_40px_rgba(165,107,255,0.25)] flex flex-col justify-between"
          >
            {/* Photo Frame Container */}
            <div className="relative aspect-[4/5] overflow-hidden rounded-2xl bg-cosmic-black mb-4">
              <img
                src={memory.image}
                alt={memory.title}
                loading="lazy"
                className="w-full h-full object-cover object-center group-hover:scale-108 transition-transform duration-700"
              />

              {/* Gradient Aura Overlay on Hover */}
              <div className="absolute inset-0 bg-gradient-to-t from-cosmic-black/90 via-cosmic-black/20 to-transparent opacity-60 group-hover:opacity-85 transition-opacity duration-300" />

              {/* View Fullscreen icon badge */}
              <div className="absolute top-3 right-3 w-9 h-9 rounded-full bg-cosmic-black/70 backdrop-blur-md border border-white/20 flex items-center justify-center text-white opacity-0 group-hover:opacity-100 transition-opacity duration-300 shadow-lg">
                <Eye size={16} />
              </div>

              {/* Category Pill Tag inside photo */}
              <div className="absolute top-3 left-3 px-2.5 py-1 rounded-full text-[10px] font-semibold tracking-wider uppercase bg-cosmic-black/80 backdrop-blur-md text-cosmic-gold border border-cosmic-violet/30">
                {memory.category}
              </div>

              {/* Bottom Snippet Inside Photo */}
              <div className="absolute bottom-3 left-3 right-3 text-left">
                <p className="text-xs text-purple-200/90 line-clamp-2 italic font-light">
                  "{memory.caption}"
                </p>
              </div>
            </div>

            {/* Photo Card Details */}
            <div className="px-1 text-left">
              <div className="flex items-center justify-between text-xs text-purple-300/70 mb-1">
                {memory.date && (
                  <span className="flex items-center gap-1 font-mono text-[11px]">
                    <Calendar size={11} className="text-cosmic-pink" />
                    {memory.date}
                  </span>
                )}
                <span className="flex items-center gap-1 text-[11px] text-cosmic-gold group-hover:text-cosmic-pink transition-colors">
                  <Sparkles size={11} />
                  <span>Tap to Enlarge</span>
                </span>
              </div>

              <h2 className="font-serif text-lg font-bold text-white group-hover:text-gradient-gold transition-colors">
                {memory.title}
              </h2>
            </div>
          </div>
        ))}
      </div>

      {/* Full-Screen Lightbox Viewer */}
      <Lightbox
        items={filteredMemories}
        currentIndex={activePhotoIndex}
        isOpen={lightboxOpen}
        onClose={() => setLightboxOpen(false)}
        onPrev={prevPhoto}
        onNext={nextPhoto}
      />

      {/* Next Page Prompt */}
      <div className="mt-20 text-center">
        <div className="glass-panel max-w-xl mx-auto p-6 rounded-3xl border border-cosmic-violet/30">
          <Sparkles size={22} className="text-cosmic-gold mx-auto mb-2 animate-spin-slow" />
          <h3 className="font-serif text-xl font-bold text-white mb-2">
            A Letter Awaits in the Galaxy
          </h3>
          <p className="text-xs sm:text-sm text-purple-200/80 mb-5">
            A floating celestial envelope holds words written just for your birthday.
          </p>
          <Link
            to="/letter"
            className="inline-flex items-center gap-2 px-6 py-3 rounded-full bg-gradient-to-r from-amber-400 to-pink-500 text-white font-semibold text-xs shadow-glow-gold hover:scale-105 active:scale-95 transition-all"
          >
            <span>Read Your Love Letter</span>
            <ArrowRight size={14} />
          </Link>
        </div>
      </div>
    </div>
  );
};
