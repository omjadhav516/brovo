export interface StoryChapter {
  id: string;
  stepNumber: number;
  chapterTitle: string;
  constellation: string;
  dateBadge: string;
  image: string;
  caption: string;
  personalMessage: string;
  reflection: string;
}

export const storyChapters: StoryChapter[] = [
  {
    id: 'chapter-1',
    stepNumber: 1,
    chapterTitle: 'How our story began',
    constellation: 'Constellation of Beginnings',
    dateBadge: '[Editable Date: The Day Our Paths Crossed]',
    image: '/images/memories/sayali_hero.jpg',
    caption: 'The moment that changed everything.',
    personalMessage: 'When you first came into my life, it felt like the universe quietly aligned every star to lead me straight to you. Meeting you wasn’t just a moment—it was the beginning of my favorite chapter.',
    reflection: 'Even a single glance from you was enough to know you were going to be someone unforgettable.'
  },
  {
    id: 'chapter-2',
    stepNumber: 2,
    chapterTitle: 'Our first special memory',
    constellation: 'Nebula of First Whispers',
    dateBadge: '[Editable Date: Our First Heart-to-Heart]',
    image: '/images/memories/couple_nature.jpg',
    caption: 'Conversations that lasted for hours without noticing the time.',
    personalMessage: 'Remember our very first long talk where neither of us wanted the day to end? That effortless comfort and natural laughter proved right away how deeply connected we are.',
    reflection: 'From that day on, every walk felt sweeter and every conversation felt like coming home.'
  },
  {
    id: 'chapter-3',
    stepNumber: 3,
    chapterTitle: 'Our happiest moments',
    constellation: 'Supernova of Pure Joy',
    dateBadge: '[Editable Date: Days of Endless Laughter]',
    image: '/images/memories/couple_traditional.jpg',
    caption: 'Dressed up, celebrating life, and feeling on top of the world.',
    personalMessage: 'Whenever we celebrate festivals or special days together, seeing you radiant in vibrant colors fills my heart with immense gratitude. Those days of sharing traditions and celebrating our love are golden.',
    reflection: 'Your happiness is infectious, and being the reason behind your smile is my greatest privilege.'
  },
  {
    id: 'chapter-4',
    stepNumber: 4,
    chapterTitle: 'Our funniest memories',
    constellation: 'Corona of Playful Spirits',
    dateBadge: '[Editable Date: Our Unfiltered Goofy Moments]',
    image: '/images/memories/couple_sweet.jpg',
    caption: 'The moments between photo poses when we couldn’t stop giggling.',
    personalMessage: 'Behind all the polished photos are the silly faces, the teased comments, and the uncontrollable fits of laughter. You make ordinary days feel delightfully fun.',
    reflection: 'Life is so much lighter and brighter with your playful spirit by my side.'
  },
  {
    id: 'chapter-5',
    stepNumber: 5,
    chapterTitle: 'Our favorite photographs',
    constellation: 'Galaxy of Timeless Portraits',
    dateBadge: '[Editable Date: The Glamour & Grace]',
    image: '/images/memories/sayali_glamour.jpg',
    caption: 'Stunning in every light, captivating from every angle.',
    personalMessage: 'Whenever I look at this portrait of you, I am reminded of how regal and poised you are. But more than that, I know the kind, gentle soul that shines behind those beautiful eyes.',
    reflection: 'You are artwork, poetry, and starlight all woven into one extraordinary person.'
  },
  {
    id: 'chapter-6',
    stepNumber: 6,
    chapterTitle: 'The moments we treasure',
    constellation: 'Pillars of Devotion',
    dateBadge: '[Editable Date: Quiet Cozy Evenings]',
    image: '/images/memories/couple_sweet.jpg',
    caption: 'Wrapped in each other’s arms, letting the world fade away.',
    personalMessage: 'It’s the quiet, peaceful moments—resting your head on my shoulder, sharing a simple tea, listening to music together—that mean the absolute world to me. Love is calmest with you.',
    reflection: 'In a noisy world, your embrace is my absolute sanctuary.'
  },
  {
    id: 'chapter-7',
    stepNumber: 7,
    chapterTitle: 'Our story continues',
    constellation: 'The Infinite Horizon',
    dateBadge: 'Today, Tomorrow & All Our Ever-Afters',
    image: '/images/memories/sayali_hero.jpg',
    caption: 'The best chapters of our universe are yet to be written.',
    personalMessage: 'As you celebrate this new year of your life, know that I am walking beside you through every dream, every adventure, and every milestone. Here’s to many more constellations in our galaxy.',
    reflection: 'Happy Birthday, my Sayali. Our story is my favorite love story in all the stars.'
  }
];
