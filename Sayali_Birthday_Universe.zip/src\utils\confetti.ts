// Cosmic celebratory confetti & particle burst utility

export const launchConfetti = () => {
  const canvas = document.createElement('canvas');
  canvas.id = 'cosmic-confetti-canvas';
  canvas.style.position = 'fixed';
  canvas.style.top = '0';
  canvas.style.left = '0';
  canvas.style.width = '100vw';
  canvas.style.height = '100vh';
  canvas.style.pointerEvents = 'none';
  canvas.style.zIndex = '9999';
  document.body.appendChild(canvas);

  const ctx = canvas.getContext('2d');
  if (!ctx) return;

  const width = (canvas.width = window.innerWidth);
  const height = (canvas.height = window.innerHeight);

  const colors = ['#FFD88A', '#FF82B2', '#A56BFF', '#FF4E88', '#F5B041', '#FFFFFF'];
  const particleCount = 140;

  interface Particle {
    x: number;
    y: number;
    w: number;
    h: number;
    vx: number;
    vy: number;
    rotation: number;
    vRotation: number;
    color: string;
    opacity: number;
    shape: 'rect' | 'circle' | 'star';
  }

  const particles: Particle[] = [];

  for (let i = 0; i < particleCount; i++) {
    const shapes: ('rect' | 'circle' | 'star')[] = ['rect', 'circle', 'star'];
    particles.push({
      x: width / 2 + (Math.random() - 0.5) * 100,
      y: height * 0.45 + (Math.random() - 0.5) * 100,
      w: Math.random() * 9 + 5,
      h: Math.random() * 9 + 5,
      vx: (Math.random() - 0.5) * 16,
      vy: Math.random() * -18 - 4,
      rotation: Math.random() * Math.PI * 2,
      vRotation: (Math.random() - 0.5) * 0.25,
      color: colors[Math.floor(Math.random() * colors.length)],
      opacity: 1,
      shape: shapes[Math.floor(Math.random() * shapes.length)],
    });
  }

  let frame = 0;
  const render = () => {
    ctx.clearRect(0, 0, width, height);
    let alive = false;

    particles.forEach((p) => {
      p.x += p.vx;
      p.y += p.vy;
      p.vy += 0.45; // Gravity
      p.vx *= 0.98; // Air drag
      p.rotation += p.vRotation;
      p.opacity -= 0.009;

      if (p.opacity > 0) {
        alive = true;
        ctx.save();
        ctx.translate(p.x, p.y);
        ctx.rotate(p.rotation);
        ctx.globalAlpha = Math.max(0, p.opacity);
        ctx.fillStyle = p.color;

        if (p.shape === 'circle') {
          ctx.beginPath();
          ctx.arc(0, 0, p.w / 2, 0, Math.PI * 2);
          ctx.fill();
        } else if (p.shape === 'star') {
          ctx.beginPath();
          ctx.moveTo(0, -p.w);
          ctx.lineTo(p.w * 0.3, -p.w * 0.3);
          ctx.lineTo(p.w, 0);
          ctx.lineTo(p.w * 0.3, p.w * 0.3);
          ctx.lineTo(0, p.w);
          ctx.lineTo(-p.w * 0.3, p.w * 0.3);
          ctx.lineTo(-p.w, 0);
          ctx.lineTo(-p.w * 0.3, -p.w * 0.3);
          ctx.closePath();
          ctx.fill();
        } else {
          ctx.fillRect(-p.w / 2, -p.h / 2, p.w, p.h);
        }

        ctx.restore();
      }
    });

    frame++;
    if (alive && frame < 180) {
      requestAnimationFrame(render);
    } else {
      canvas.remove();
    }
  };

  requestAnimationFrame(render);
};
