import React, { useState, useEffect, useRef } from 'react';
import { Volume2, VolumeX, Play, Pause, Music, Sparkles } from 'lucide-react';
import { siteConfig } from '../data/siteConfig';

export const AudioPlayer: React.FC = () => {
  const [isPlaying, setIsPlaying] = useState<boolean>(false);
  const [isMuted, setIsMuted] = useState<boolean>(false);
  const [volume, setVolume] = useState<number>(0.6);
  const [isSynthesizing, setIsSynthesizing] = useState<boolean>(false);
  const [audioSource, setAudioSource] = useState<'file' | 'synth'>('synth');

  const audioRef = useRef<HTMLAudioElement | null>(null);
  const audioCtxRef = useRef<AudioContext | null>(null);
  const synthTimerRef = useRef<number | null>(null);
  const gainNodeRef = useRef<GainNode | null>(null);

  // Romantic celestial chord notes (Hz) for procedural space ambient melody
  // Beautiful romantic chords in D major / B minor: D, F#, A, B, C#, E
  const scaleNotes = [
    293.66, // D4
    369.99, // F#4
    440.00, // A4
    493.88, // B4
    554.37, // C#5
    587.33, // D5
    659.25, // E5
    739.99, // F#5
    880.00  // A5
  ];

  // Try file audio first, fallback to synthesized celestial chimes
  useEffect(() => {
    const audio = new Audio();
    audio.src = siteConfig.music.src || '/audio/universe.mp3';
    audio.loop = true;
    audio.volume = volume;
    audioRef.current = audio;

    const handleCanPlay = () => {
      setAudioSource('file');
    };
    const handleError = () => {
      // Local mp3 not present yet; synthesizer is ready
      setAudioSource('synth');
    };

    audio.addEventListener('canplaythrough', handleCanPlay);
    audio.addEventListener('error', handleError);

    return () => {
      audio.removeEventListener('canplaythrough', handleCanPlay);
      audio.removeEventListener('error', handleError);
      audio.pause();
      stopSynthesizer();
    };
  }, []);

  // Update volume
  useEffect(() => {
    if (audioRef.current) {
      audioRef.current.volume = isMuted ? 0 : volume;
    }
    if (gainNodeRef.current && audioCtxRef.current) {
      gainNodeRef.current.gain.setTargetAtTime(
        isMuted ? 0 : volume * 0.25,
        audioCtxRef.current.currentTime,
        0.05
      );
    }
  }, [volume, isMuted]);

  const startSynthesizer = () => {
    try {
      const AudioContextClass = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
      if (!audioCtxRef.current) {
        audioCtxRef.current = new AudioContextClass();
      }
      if (audioCtxRef.current.state === 'suspended') {
        audioCtxRef.current.resume();
      }

      const ctx = audioCtxRef.current;
      const masterGain = ctx.createGain();
      masterGain.gain.setValueAtTime(isMuted ? 0 : volume * 0.25, ctx.currentTime);
      masterGain.connect(ctx.destination);
      gainNodeRef.current = masterGain;

      setIsSynthesizing(true);

      let step = 0;
      const playChime = () => {
        if (!audioCtxRef.current || audioCtxRef.current.state === 'closed') return;
        const now = audioCtxRef.current.currentTime;

        // Create warm bell-like oscillator
        const osc = audioCtxRef.current.createOscillator();
        const noteGain = audioCtxRef.current.createGain();

        // Romantic melody pattern sequence
        const noteIndex = [0, 2, 4, 5, 4, 2, 7, 6, 4, 3, 2, 1][step % 12];
        const freq = scaleNotes[noteIndex % scaleNotes.length];
        osc.type = step % 4 === 0 ? 'sine' : 'triangle';
        osc.frequency.setValueAtTime(freq, now);

        // Soft bell envelope with long decay
        noteGain.gain.setValueAtTime(0.001, now);
        noteGain.gain.linearRampToValueAtTime(0.18, now + 0.12);
        noteGain.gain.exponentialRampToValueAtTime(0.0001, now + 2.8);

        osc.connect(noteGain);
        noteGain.connect(masterGain);

        osc.start(now);
        osc.stop(now + 3.0);

        step++;
        // Gentle relaxed pacing
        synthTimerRef.current = window.setTimeout(playChime, 1400);
      };

      playChime();
    } catch {
      // AudioContext not supported or restricted
    }
  };

  const stopSynthesizer = () => {
    if (synthTimerRef.current) {
      clearTimeout(synthTimerRef.current);
      synthTimerRef.current = null;
    }
    setIsSynthesizing(false);
  };

  const togglePlay = () => {
    if (isPlaying) {
      if (audioSource === 'file' && audioRef.current) {
        audioRef.current.pause();
      }
      stopSynthesizer();
      setIsPlaying(false);
    } else {
      if (audioSource === 'file' && audioRef.current) {
        audioRef.current.play().then(() => {
          setIsPlaying(true);
        }).catch(() => {
          // Fallback to synth if file fails to start
          setAudioSource('synth');
          startSynthesizer();
          setIsPlaying(true);
        });
      } else {
        startSynthesizer();
        setIsPlaying(true);
      }
    }
  };

  const toggleMute = () => {
    setIsMuted(!isMuted);
  };

  return (
    <div 
      className="flex items-center gap-2 bg-cosmic-navy/70 border border-cosmic-violet/30 rounded-full px-3 py-1.5 backdrop-blur-md shadow-glow-violet/20"
      title="Cosmic Melody for Sayali"
    >
      <button
        onClick={togglePlay}
        aria-label={isPlaying ? "Pause soundtrack" : "Play romantic soundtrack"}
        className="w-7 h-7 rounded-full bg-gradient-to-r from-cosmic-purple to-cosmic-pink flex items-center justify-center text-white hover:scale-105 active:scale-95 transition-transform"
      >
        {isPlaying ? <Pause size={13} /> : <Play size={13} className="ml-0.5" />}
      </button>

      <div className="hidden sm:flex flex-col">
        <span className="text-[10px] text-cosmic-gold font-medium leading-tight flex items-center gap-1">
          <Music size={10} className="text-cosmic-pink animate-pulse" />
          <span>Sayali's Universe Melody</span>
        </span>
        <span className="text-[9px] text-purple-300/80 leading-tight">
          {isPlaying ? (audioSource === 'file' ? 'Cosmic Serenade' : 'Celestial Bells') : 'Click to Play Music'}
        </span>
      </div>

      {/* Animated Sound Wave Bars */}
      {isPlaying && (
        <div className="flex items-end gap-0.5 h-3 px-1">
          <span className="w-0.5 bg-cosmic-gold rounded-full animate-bounce h-2" style={{ animationDelay: '0ms' }} />
          <span className="w-0.5 bg-cosmic-pink rounded-full animate-bounce h-3" style={{ animationDelay: '150ms' }} />
          <span className="w-0.5 bg-cosmic-violet rounded-full animate-bounce h-2" style={{ animationDelay: '300ms' }} />
          <span className="w-0.5 bg-cosmic-gold rounded-full animate-bounce h-3" style={{ animationDelay: '75ms' }} />
        </div>
      )}

      {/* Mute Button */}
      <button
        onClick={toggleMute}
        aria-label={isMuted ? "Unmute" : "Mute"}
        className="text-purple-300 hover:text-white transition-colors p-1"
      >
        {isMuted ? <VolumeX size={14} /> : <Volume2 size={14} />}
      </button>

      {/* Volume slider */}
      <input
        type="range"
        min="0"
        max="1"
        step="0.05"
        value={isMuted ? 0 : volume}
        onChange={(e) => {
          setVolume(parseFloat(e.target.value));
          if (isMuted) setIsMuted(false);
        }}
        aria-label="Sound volume"
        className="w-12 h-1 accent-cosmic-pink bg-purple-950 rounded-lg cursor-pointer"
      />
    </div>
  );
};
