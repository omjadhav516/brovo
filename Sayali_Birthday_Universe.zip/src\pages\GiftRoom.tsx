import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { 
  Gift, 
  Sparkles, 
  Heart, 
  X, 
  ArrowRight, 
  PartyPopper, 
  Star, 
  Sun, 
  Shield, 
  Image as ImageIcon 
} from 'lucide-react';
import { giftsData, GiftItem } from '../data/gifts';
import { PageHeader } from '../components/PageHeader';
import { launchConfetti } from '../utils/confetti';
import { FairyLights } from '../components/FairyLights';
import { ConstellationCanvas } from '../components/ConstellationCanvas';

export const GiftRoom: React.FC = () => {
  const [selectedGift, setSelectedGift] = useState<GiftItem | null>(null);
  const [openedGifts, setOpenedGifts] = useState<number[]>([]);

  const handleOpenGift = (gift: GiftItem) => {
    setSelectedGift(gift);
    if (!openedGifts.includes(gift.id)) {
      setOpenedGifts((prev) => [...prev, gift.id]);
    }
    // If it's the confetti gift or grand finale, blast confetti!
    if (gift.type === 'confetti-greeting' || gift.type === 'grand-finale') {
      launchConfetti();
    }
  };

  const getReasonIcon = (iconName: string) => {
    switch (iconName) {
      case 'Heart':
        return <Heart size={18} className="text-cosmic-pink fill-cosmic-pink" />;
      case 'Sun':
        return <Sun size={18} className="text-amber-400" />;
      case 'Shield':
        return <Shield size={18} className="text-sky-400" />;
      default:
        return <Sparkles size={18} className="text-cosmic-gold" />;
    }
  };

  return (
    <div className="relative min-h-screen py-10 px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto flex flex-col justify-between">
      <ConstellationCanvas dotCount={40} connectDistance={110} />
      <FairyLights curve="arch" bulbCount={18} />

      <PageHeader
        badge="Surprises in the Cosmos"
        title="The Birthday Surprise Gift Room"
        subtitle="Six enchanted cosmic boxes wrapped in ribbons of light. Each one holds a distinct surprise, memory, or celebration."
      />

      {/* Progress tracker */}
      <div className="flex items-center justify-center gap-3 mb-10 text-xs font-mono text-purple-300/80">
        <Sparkles size={13} className="text-cosmic-gold" />
        <span>Boxes Opened: {openedGifts.length} of 6</span>
        <div className="w-28 h-2 bg-cosmic-navy rounded-full overflow-hidden border border-cosmic-violet/30">
          <div 
            className="h-full bg-gradient-to-r from-cosmic-purple to-cosmic-gold transition-all duration-500"
            style={{ width: `${(openedGifts.length / 6) * 100}%` }}
          />
        </div>
      </div>

      {/* 6 Interactive Gift Boxes Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6 sm:gap-8 max-w-6xl mx-auto w-full">
        {giftsData.map((gift) => {
          const isOpened = openedGifts.includes(gift.id);

          return (
            <div
              key={gift.id}
              onClick={() => handleOpenGift(gift)}
              className="group relative cursor-pointer glass-panel p-6 rounded-3xl border border-cosmic-violet/30 hover:border-cosmic-pink/60 transition-all duration-500 hover:-translate-y-2 hover:shadow-[0_15px_45px_rgba(165,107,255,0.3)] flex flex-col items-center text-center justify-between min-h-[300px]"
              role="button"
              tabIndex={0}
              aria-label={`Open Gift ${gift.boxNumber}: ${gift.title}`}
              onKeyDown={(e) => {
                if (e.key === 'Enter' || e.key === ' ') handleOpenGift(gift);
              }}
            >
              {/* Box Number Tag */}
              <div className="w-full flex items-center justify-between text-xs text-purple-300/70 mb-3">
                <span className="font-mono text-cosmic-gold font-bold">
                  BOX {gift.boxNumber}
                </span>
                <span className={`px-2 py-0.5 rounded-full text-[10px] uppercase tracking-wider font-semibold ${
                  isOpened
                    ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/30'
                    : 'bg-cosmic-purple/30 text-purple-200 border border-cosmic-violet/30'
                }`}>
                  {isOpened ? 'Opened ✨' : 'Unopened'}
                </span>
              </div>

              {/* 3D-styled Cosmic Gift Box Illustration */}
              <div className="relative my-4 group-hover:scale-110 transition-transform duration-500">
                {/* Luminous Glow Behind Box */}
                <div 
                  className="absolute -inset-4 rounded-full blur-xl opacity-60 group-hover:opacity-100 transition-opacity duration-500" 
                  style={{ backgroundColor: gift.glowColor }} 
                />

                {/* Box body */}
                <div className="relative w-28 h-28 sm:w-32 sm:h-32 rounded-2xl bg-gradient-to-br from-[#251A4D] via-[#171333] to-[#0A0D22] border-2 border-cosmic-violet/50 shadow-2xl overflow-hidden flex items-center justify-center">
                  
                  {/* Vertical Ribbon */}
                  <div className={`absolute inset-y-0 w-6 bg-gradient-to-r ${gift.ribbonColor} shadow-md`} />
                  
                  {/* Horizontal Ribbon */}
                  <div className={`absolute inset-x-0 h-6 bg-gradient-to-b ${gift.ribbonColor} shadow-md`} />

                  {/* Ribbon Bow on top */}
                  <div className="relative z-10 w-11 h-11 rounded-full bg-gradient-to-tr from-amber-300 via-rose-300 to-amber-500 shadow-glow-gold flex items-center justify-center group-hover:rotate-45 transition-transform duration-500">
                    <Sparkles size={16} className="text-cosmic-black" />
                  </div>
                </div>
              </div>

              {/* Gift Title & Description */}
              <div className="mt-3">
                <h2 className="font-serif text-lg font-bold text-white group-hover:text-gradient-gold transition-colors">
                  {gift.title}
                </h2>
                <p className="text-xs text-purple-200/70 mt-1 line-clamp-2">
                  {gift.subtitle}
                </p>
              </div>

              {/* Click to open badge */}
              <div className="mt-4 pt-3 border-t border-purple-900/30 w-full flex items-center justify-center gap-1.5 text-xs text-cosmic-pink font-semibold group-hover:translate-y-[-2px] transition-transform">
                <span>{isOpened ? 'Re-open Surprise' : 'Tap to Open Box'}</span>
                <ArrowRight size={13} />
              </div>
            </div>
          );
        })}
      </div>

      {/* Gift Content Modal / Dialog */}
      {selectedGift && (
        <div 
          className="fixed inset-0 z-50 flex items-center justify-center bg-cosmic-black/90 backdrop-blur-2xl p-4 sm:p-6 animate-in fade-in duration-300"
          role="dialog"
          aria-modal="true"
        >
          <div className="relative w-full max-w-2xl max-h-[90vh] overflow-y-auto glass-panel p-6 sm:p-8 rounded-3xl border border-cosmic-pink/40 shadow-[0_0_60px_rgba(255,130,178,0.3)] text-center">
            
            {/* Close Button */}
            <button
              onClick={() => setSelectedGift(null)}
              aria-label="Close gift dialog"
              className="absolute top-4 right-4 p-2 rounded-full bg-cosmic-navy/90 border border-cosmic-violet/40 text-purple-200 hover:text-white hover:bg-cosmic-purple/60 transition-all hover:scale-105 active:scale-95"
            >
              <X size={18} />
            </button>

            {/* Badge */}
            <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-semibold uppercase tracking-wider bg-cosmic-purple/40 text-cosmic-gold border border-cosmic-violet/40 mb-3">
              <Sparkles size={12} className="text-cosmic-pink" />
              <span>{selectedGift.content.badge || `Surprise Box ${selectedGift.boxNumber}`}</span>
            </div>

            {/* Heading */}
            <h2 className="font-serif text-2xl sm:text-3xl font-bold text-white mb-1">
              {selectedGift.content.heading}
            </h2>

            {/* Subheading */}
            {selectedGift.content.subheading && (
              <p className="text-xs sm:text-sm text-cosmic-pink font-medium italic mb-6">
                {selectedGift.content.subheading}
              </p>
            )}

            {/* Photo Type */}
            {selectedGift.content.image && (
              <div className="relative rounded-2xl overflow-hidden p-1.5 bg-gradient-to-tr from-cosmic-purple via-cosmic-pink to-cosmic-gold shadow-2xl mb-6 max-w-md mx-auto">
                <img
                  src={selectedGift.content.image}
                  alt={selectedGift.content.heading}
                  className="rounded-xl w-full max-h-[48vh] object-cover bg-cosmic-black"
                />
                {selectedGift.content.caption && (
                  <p className="text-xs text-purple-100/90 italic p-3 text-center bg-cosmic-black/80 backdrop-blur-md">
                    "{selectedGift.content.caption}"
                  </p>
                )}
              </div>
            )}

            {/* Reasons to Smile Type */}
            {selectedGift.content.reasons && (
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 mb-6 text-left">
                {selectedGift.content.reasons.map((r, i) => (
                  <div key={i} className="glass-card p-4 rounded-xl border border-cosmic-violet/30">
                    <div className="flex items-center gap-2 mb-1.5">
                      <div className="p-1.5 rounded-lg bg-cosmic-purple/40">
                        {getReasonIcon(r.icon)}
                      </div>
                      <h4 className="font-serif text-sm font-bold text-white">{r.title}</h4>
                    </div>
                    <p className="text-xs text-purple-200/80 leading-relaxed font-light">{r.desc}</p>
                  </div>
                ))}
              </div>
            )}

            {/* Body Text */}
            {selectedGift.content.bodyText && (
              <p className="text-sm sm:text-base text-purple-100/95 leading-relaxed font-light max-w-xl mx-auto mb-6">
                {selectedGift.content.bodyText}
              </p>
            )}

            {/* Celebratory Buttons */}
            <div className="flex flex-wrap items-center justify-center gap-3 pt-4 border-t border-purple-900/30">
              <button
                onClick={launchConfetti}
                className="px-5 py-2.5 rounded-full bg-gradient-to-r from-amber-400 to-pink-500 text-white font-semibold text-xs shadow-glow-gold hover:scale-105 active:scale-95 transition-all flex items-center gap-1.5"
              >
                <PartyPopper size={14} />
                <span>Launch Confetti ✨</span>
              </button>

              <button
                onClick={() => setSelectedGift(null)}
                className="px-5 py-2.5 rounded-full bg-cosmic-navy hover:bg-cosmic-purple/50 border border-cosmic-violet/40 text-purple-200 text-xs transition-colors"
              >
                Close Box
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Next Step Link */}
      <div className="mt-16 text-center">
        <Link
          to="/moments"
          className="inline-flex items-center gap-2 px-6 py-3 rounded-full bg-cosmic-navy/90 hover:bg-cosmic-purple/50 border border-cosmic-violet/40 text-cosmic-white font-semibold text-xs shadow-lg hover:scale-105 active:scale-95 transition-all"
        >
          <span>Watch Our Special Moments Slideshow</span>
          <ArrowRight size={14} />
        </Link>
      </div>
    </div>
  );
};
