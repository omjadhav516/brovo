import React, { useState } from 'react';
import { NavLink, Link } from 'react-router-dom';
import { 
  Sparkles, 
  Heart, 
  BookOpen, 
  Image as GalleryIcon, 
  Mail, 
  Gift, 
  Film, 
  Menu, 
  X,
  Compass
} from 'lucide-react';
import { AudioPlayer } from './AudioPlayer';
import { siteConfig } from '../data/siteConfig';

export const Navbar: React.FC = () => {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const navLinks = [
    { to: '/', label: 'Home', icon: Compass },
    { to: '/story', label: 'Our Story', icon: BookOpen },
    { to: '/gallery', label: 'Memory Galaxy', icon: GalleryIcon },
    { to: '/letter', label: 'A Love Letter', icon: Mail },
    { to: '/gifts', label: 'Gift Room', icon: Gift },
    { to: '/moments', label: 'Moments', icon: Film },
    { to: '/finale', label: 'Finale', icon: Heart, highlight: true },
  ];

  return (
    <header className="sticky top-0 z-50 w-full backdrop-blur-xl bg-cosmic-black/75 border-b border-cosmic-violet/20 transition-all duration-300">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between gap-2">
        {/* Brand / Logo */}
        <Link 
          to="/" 
          className="flex items-center gap-2 group text-decoration-none focus:outline-none"
        >
          <div className="w-9 h-9 rounded-full bg-gradient-to-tr from-cosmic-purple via-cosmic-violet to-cosmic-pink p-[1px] shadow-glow-violet/30 transition-transform duration-300 group-hover:scale-110">
            <div className="w-full h-full bg-cosmic-black rounded-full flex items-center justify-center">
              <Sparkles size={16} className="text-cosmic-gold group-hover:rotate-12 transition-transform" />
            </div>
          </div>
          <div className="flex flex-col">
            <span className="font-serif tracking-widest text-lg font-bold text-gradient-gold">
              {siteConfig.recipientName.toUpperCase()}
            </span>
            <span className="text-[9px] uppercase tracking-wider text-purple-300/70 -mt-1 font-sans">
              Our Universe
            </span>
          </div>
        </Link>

        {/* Desktop Navigation Links */}
        <nav className="hidden lg:flex items-center gap-1 xl:gap-2">
          {navLinks.map((link) => {
            const Icon = link.icon;
            return (
              <NavLink
                key={link.to}
                to={link.to}
                className={({ isActive }) =>
                  `flex items-center gap-1.5 px-3 py-1.5 rounded-full text-xs font-medium transition-all duration-200 ${
                    isActive
                      ? 'bg-gradient-to-r from-cosmic-purple/70 to-cosmic-violet/50 text-white shadow-glow-violet/40 border border-cosmic-violet/40'
                      : link.highlight
                      ? 'text-cosmic-pink hover:text-white hover:bg-cosmic-pink/15 border border-cosmic-pink/30'
                      : 'text-purple-200/80 hover:text-white hover:bg-white/5'
                  }`
                }
              >
                <Icon size={13} className={link.highlight ? 'text-cosmic-pink' : ''} />
                <span>{link.label}</span>
              </NavLink>
            );
          })}
        </nav>

        {/* Right Section: Audio Player & Mobile Toggle */}
        <div className="flex items-center gap-2">
          <AudioPlayer />

          {/* Mobile hamburger button */}
          <button
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            aria-label="Toggle navigation menu"
            className="lg:hidden p-2 rounded-lg bg-cosmic-navy/80 border border-cosmic-violet/30 text-purple-200 hover:text-white hover:border-cosmic-pink/50 transition-colors"
          >
            {mobileMenuOpen ? <X size={20} /> : <Menu size={20} />}
          </button>
        </div>
      </div>

      {/* Mobile Drawer Menu */}
      {mobileMenuOpen && (
        <div className="lg:hidden fixed inset-x-0 top-16 bg-cosmic-black/95 backdrop-blur-2xl border-b border-cosmic-violet/30 p-4 shadow-2xl animate-in slide-in-from-top-2 duration-200">
          <nav className="flex flex-col gap-2 max-w-md mx-auto">
            {navLinks.map((link) => {
              const Icon = link.icon;
              return (
                <NavLink
                  key={link.to}
                  to={link.to}
                  onClick={() => setMobileMenuOpen(false)}
                  className={({ isActive }) =>
                    `flex items-center gap-3 px-4 py-2.5 rounded-xl text-sm font-medium transition-all ${
                      isActive
                        ? 'bg-gradient-to-r from-cosmic-purple to-cosmic-violet text-white shadow-lg'
                        : 'text-purple-200 hover:text-white hover:bg-white/5'
                    }`
                  }
                >
                  <Icon size={16} className={link.highlight ? 'text-cosmic-pink' : 'text-cosmic-gold'} />
                  <span>{link.label}</span>
                </NavLink>
              );
            })}
          </nav>
        </div>
      )}
    </header>
  );
};
