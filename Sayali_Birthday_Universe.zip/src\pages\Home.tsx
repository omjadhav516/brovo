import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { 
  Sparkles, 
  Heart, 
  BookOpen, 
  Image as GalleryIcon, 
  Gift, 
  ArrowRight, 
  ChevronDown, 
  Mail, 
  Compass,
  Star,
  Play
} from 'lucide-react';
import { siteConfig } from '../data/siteConfig';
import { FairyLights } from '../components/FairyLights';
import { ConstellationCanvas } from '../components/ConstellationCanvas';

export const Home: React.FC = () => {
  // Intro animation sequence stages: 0 = darkness, 1 = line 1, 2 = line 2, 3 = line 3 ("SAYALI ❤️"), 4 = full reveal
  const [introStage, setIntroStage] = useState<number>(() => {
    // Check if intro has already been viewed in this session
    return sessionStorage.getItem('sayali_intro_seen') ? 4 : 1;
  });

  useEffect(() => {
    if (introStage === 4) return;

    const timer1 = setTimeout(() => setIntroStage(2), 2200);
    const timer2 = setTimeout(() => setIntroStage(3), 4400);
    const timer3 = setTimeout(() => {
      setIntroStage(4);
      sessionStorage.setItem('sayali_intro_seen', 'true');
    }, 6600);

    return () => {
      clearTimeout(timer1);
      clearTimeout(timer2);
      clearTimeout(timer3);
    };
  }, [introStage]);

  const skipIntro = () => {
    setIntroStage(4);
    sessionStorage.setItem('sayali_intro_seen', 'true');
  };

  return (
    <div className="relative min-h-[calc(100vh-4rem)] flex flex-col justify-between overflow-hidden">
      {/* Interactive Constellation Canvas overlay */}
      <ConstellationCanvas dotCount={50} connectDistance={110} />

      {/* Fairy lights along the top */}
      <FairyLights curve="arch" bulbCount={18} />

      {/* Cinematic Intro Overlay (if not skipped/completed) */}
      {introStage < 4 && (
        <div className="fixed inset-0 z-50 flex flex-col items-center justify-center bg-cosmic-black px-6 text-center transition-opacity duration-1000">
          {/* Subtle cosmic aura */}
          <div className="absolute w-[80vw] h-[80vw] max-w-[500px] max-h-[500px] rounded-full bg-cosmic-purple/20 blur-[100px] animate-pulse-slow pointer-events-none" />

          {/* Intro Lines */}
          <div className="relative z-10 max-w-2xl min-h-[160px] flex flex-col items-center justify-center">
            {introStage >= 1 && (
              <p 
                className={`text-xl sm:text-2xl md:text-3xl font-light text-purple-200/90 tracking-wide transition-all duration-700 ${
                  introStage === 1 ? 'opacity-100 scale-100' : 'opacity-40 text-sm'
                }`}
              >
                {siteConfig.heroIntroLines[0]}
              </p>
            )}

            {introStage >= 2 && (
              <p 
                className={`mt-4 text-xl sm:text-2xl md:text-3xl font-serif text-cosmic-gold tracking-wide transition-all duration-700 ${
                  introStage === 2 ? 'opacity-100 scale-105' : 'opacity-40 text-sm'
                }`}
              >
                {siteConfig.heroIntroLines[1]}
              </p>
            )}

            {introStage >= 3 && (
              <h1 className="mt-6 text-4xl sm:text-5xl md:text-7xl font-serif font-extrabold text-gradient-rose tracking-wider animate-bounce shadow-glow-pink">
                {siteConfig.heroIntroLines[2]}
              </h1>
            )}
          </div>

          {/* Skip Intro button */}
          <button
            onClick={skipIntro}
            className="mt-12 px-5 py-2 rounded-full text-xs text-purple-300 hover:text-white bg-cosmic-navy/80 border border-cosmic-violet/40 hover:border-cosmic-pink/60 transition-all shadow-glow-violet/20 flex items-center gap-2"
          >
            <span>Skip Intro & Enter</span>
            <ArrowRight size={13} />
          </button>
        </div>
      )}

      {/* Main Hero Scene (When fully revealed) */}
      <section className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 md:py-16 flex-1 flex flex-col justify-center">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 md:gap-14 items-center">
          
          {/* Left Column: Greeting and Romantic Story Opening */}
          <div className="lg:col-span-7 text-center lg:text-left">
            {/* Starlight badge */}
            <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full text-xs font-medium tracking-widest uppercase bg-cosmic-purple/30 border border-cosmic-violet/40 text-cosmic-gold mb-6 shadow-glow-violet/20">
              <Sparkles size={13} className="text-cosmic-pink animate-spin-slow" />
              <span>A Birthday Universe For Sayali</span>
              <Heart size={12} className="text-cosmic-pink fill-cosmic-pink" />
            </div>

            {/* Main Greeting */}
            <h1 className="text-4xl sm:text-5xl md:text-6xl xl:text-7xl font-serif font-extrabold tracking-tight leading-[1.1] text-gradient-cosmic mb-6">
              {siteConfig.heroMainGreeting}
            </h1>

            {/* Supporting Emotional Message */}
            <p className="text-lg sm:text-xl text-purple-100/90 font-light leading-relaxed max-w-2xl mb-8">
              "{siteConfig.heroSupportingMessage}"
            </p>

            {/* 3 Core Action Buttons */}
            <div className="flex flex-wrap items-center justify-center lg:justify-start gap-3 sm:gap-4 mb-10">
              <Link
                to="/story"
                className="group px-6 py-3.5 rounded-full bg-gradient-to-r from-cosmic-purple via-cosmic-violet to-cosmic-pink text-white font-semibold text-sm shadow-glow-violet hover:shadow-[0_0_35px_rgba(255,130,178,0.5)] transition-all duration-300 hover:scale-105 active:scale-95 flex items-center gap-2"
              >
                <Compass size={17} className="group-hover:rotate-45 transition-transform" />
                <span>Enter Our Universe</span>
                <ArrowRight size={15} className="group-hover:translate-x-1 transition-transform" />
              </Link>

              <Link
                to="/gallery"
                className="px-6 py-3.5 rounded-full bg-cosmic-navy/90 hover:bg-cosmic-purple/40 border border-cosmic-violet/40 hover:border-cosmic-pink/60 text-cosmic-white font-medium text-sm transition-all duration-300 hover:scale-105 active:scale-95 flex items-center gap-2 shadow-lg"
              >
                <GalleryIcon size={17} className="text-cosmic-gold" />
                <span>Discover Our Memories</span>
              </Link>

              <Link
                to="/gifts"
                className="px-6 py-3.5 rounded-full bg-gradient-to-r from-amber-500/20 to-pink-500/20 hover:from-amber-500/40 hover:to-pink-500/40 border border-cosmic-gold/50 text-cosmic-gold font-semibold text-sm transition-all duration-300 hover:scale-105 active:scale-95 flex items-center gap-2 shadow-glow-gold/30"
              >
                <Gift size={17} className="text-cosmic-pink animate-bounce" />
                <span>Open Your First Gift</span>
              </Link>
            </div>

            {/* Micro Quote */}
            <div className="flex items-center justify-center lg:justify-start gap-3 text-xs text-purple-300/60 font-mono">
              <Star size={12} className="text-cosmic-gold fill-cosmic-gold" />
              <span>Every star here belongs to you</span>
              <span>•</span>
              <span>Always & Forever</span>
            </div>
          </div>

          {/* Right Column: Sayali's Photograph in a Premium Cosmic Glowing Frame */}
          <div className="lg:col-span-5 flex justify-center">
            <div className="relative group max-w-sm sm:max-w-md w-full">
              {/* Outer Cosmic Glowing Halo & Orbit Rings */}
              <div className="absolute -inset-2 bg-gradient-to-r from-cosmic-purple via-cosmic-pink to-cosmic-gold rounded-3xl opacity-75 blur-xl group-hover:opacity-100 transition-opacity duration-700 animate-pulse-slow" />
              
              {/* Decorative Orbital Ring Accent */}
              <div className="absolute -inset-6 rounded-full border border-cosmic-violet/20 pointer-events-none scale-105 animate-spin-slow" />
              
              {/* Premium Glass Photo Container */}
              <div className="relative rounded-3xl overflow-hidden p-2 bg-cosmic-navy/80 border-2 border-cosmic-violet/50 backdrop-blur-xl shadow-2xl">
                <div className="relative aspect-[4/5] overflow-hidden rounded-2xl bg-cosmic-black">
                  <img
                    src={siteConfig.heroPhotograph}
                    alt="Sayali - The light of my universe"
                    className="w-full h-full object-cover object-center group-hover:scale-105 transition-transform duration-700"
                  />
                  
                  {/* Subtle Gradient Vignette */}
                  <div className="absolute inset-0 bg-gradient-to-t from-cosmic-black/80 via-transparent to-transparent" />

                  {/* Floating Photo Badge */}
                  <div className="absolute bottom-4 left-4 right-4 p-3 rounded-xl bg-cosmic-black/80 backdrop-blur-md border border-white/10 flex items-center justify-between">
                    <div>
                      <p className="text-xs uppercase tracking-wider text-cosmic-gold font-semibold font-serif">
                        Sayali
                      </p>
                      <p className="text-[11px] text-purple-200/80">
                        The Brightest Star In My Universe
                      </p>
                    </div>
                    <div className="w-8 h-8 rounded-full bg-gradient-to-tr from-cosmic-pink to-cosmic-purple flex items-center justify-center text-white shadow-glow-pink">
                      <Heart size={14} className="fill-white" />
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>

        </div>

        {/* Explore Universe Cards Grid: 6 Destination Portals */}
        <div className="mt-20 pt-10 border-t border-cosmic-violet/20">
          <div className="text-center mb-8">
            <h2 className="font-serif text-2xl font-bold text-gradient-gold">
              Explore Sayali's Universe
            </h2>
            <p className="text-xs sm:text-sm text-purple-300/70 mt-1">
              Select any constellation below to begin your journey
            </p>
          </div>

          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-3 sm:gap-4">
            {[
              { to: '/story', title: 'Our Story', desc: '7 Glowing Milestones', icon: BookOpen, color: 'border-purple-500/30' },
              { to: '/gallery', title: 'Memory Galaxy', desc: 'Interactive Gallery', icon: GalleryIcon, color: 'border-pink-500/30' },
              { to: '/letter', title: 'A Love Letter', desc: 'From My Heart', icon: Mail, color: 'border-amber-500/30' },
              { to: '/gifts', title: 'Gift Room', desc: '6 Special Surprises', icon: Gift, color: 'border-rose-500/30' },
              { to: '/moments', title: 'Slideshow', desc: 'Cinematic Memories', icon: Play, color: 'border-violet-500/30' },
              { to: '/finale', title: 'Grand Finale', desc: 'Make A Wish ✨', icon: Heart, color: 'border-yellow-400/40', highlight: true },
            ].map((portal, idx) => {
              const Icon = portal.icon;
              return (
                <Link
                  key={idx}
                  to={portal.to}
                  className={`glass-card p-4 rounded-2xl flex flex-col items-center text-center group border ${portal.color} hover:scale-105 active:scale-95 transition-all duration-300`}
                >
                  <div className={`w-10 h-10 rounded-full flex items-center justify-center mb-2.5 transition-transform duration-300 group-hover:rotate-12 ${
                    portal.highlight
                      ? 'bg-gradient-to-r from-amber-400 to-pink-500 text-white shadow-glow-gold'
                      : 'bg-cosmic-navy/90 text-cosmic-gold border border-cosmic-violet/30'
                  }`}>
                    <Icon size={18} />
                  </div>
                  <h3 className="font-serif text-sm font-bold text-white group-hover:text-cosmic-pink transition-colors">
                    {portal.title}
                  </h3>
                  <span className="text-[11px] text-purple-300/70 mt-0.5 font-light">
                    {portal.desc}
                  </span>
                </Link>
              );
            })}
          </div>
        </div>

        {/* Animated Scroll Indicator */}
        <div className="mt-14 flex flex-col items-center justify-center text-center">
          <Link
            to="/story"
            className="flex flex-col items-center gap-1.5 text-xs text-purple-300/70 hover:text-white transition-colors"
          >
            <span>Scroll or Click to Begin Our Love Story</span>
            <div className="w-6 h-10 rounded-full border-2 border-cosmic-violet/40 flex items-start justify-center p-1.5">
              <div className="w-1.5 h-2.5 rounded-full bg-cosmic-pink animate-bounce" />
            </div>
            <ChevronDown size={14} className="text-cosmic-gold animate-pulse -mt-0.5" />
          </Link>
        </div>
      </section>
    </div>
  );
};
