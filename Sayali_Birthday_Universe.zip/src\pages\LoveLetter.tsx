import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { 
  Mail, 
  Heart, 
  RotateCcw, 
  Sparkles, 
  ArrowRight, 
  Feather, 
  X,
  Volume2
} from 'lucide-react';
import { siteConfig } from '../data/siteConfig';
import { PageHeader } from '../components/PageHeader';
import { FairyLights } from '../components/FairyLights';
import { ConstellationCanvas } from '../components/ConstellationCanvas';

export const LoveLetter: React.FC = () => {
  const [isOpen, setIsOpen] = useState<boolean>(false);
  const [isOpening, setIsOpening] = useState<boolean>(false);

  const handleOpenEnvelope = () => {
    if (isOpen) return;
    setIsOpening(true);
    setTimeout(() => {
      setIsOpen(true);
      setIsOpening(false);
    }, 700);
  };

  const handleReplay = () => {
    setIsOpen(false);
  };

  return (
    <div className="relative min-h-screen py-10 px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto flex flex-col justify-between">
      <ConstellationCanvas dotCount={40} connectDistance={110} />
      <FairyLights curve="arch" bulbCount={16} />

      <PageHeader
        badge="From My Heart to Yours"
        title="A Letter Written in the Stars"
        subtitle="A celestial envelope floating quietly in the cosmos. Touch the seal to unfurl words crafted solely for you."
      />

      {/* Main Interactive Stage */}
      <div className="relative flex-1 flex items-center justify-center py-6 sm:py-12">
        {/* Floating Closed Envelope State */}
        {!isOpen && (
          <div className="flex flex-col items-center text-center animate-float-gentle">
            {/* Glowing Envelope Container */}
            <div
              onClick={handleOpenEnvelope}
              className={`group relative cursor-pointer w-72 sm:w-96 h-48 sm:h-64 rounded-3xl p-1 bg-gradient-to-tr from-amber-300 via-rose-400 to-purple-600 shadow-[0_0_60px_rgba(255,216,138,0.4)] transition-all duration-500 hover:scale-105 active:scale-95 ${
                isOpening ? 'scale-110 opacity-70 rotate-2' : ''
              }`}
              role="button"
              tabIndex={0}
              aria-label="Open Love Letter for Sayali"
              onKeyDown={(e) => {
                if (e.key === 'Enter' || e.key === ' ') handleOpenEnvelope();
              }}
            >
              <div className="relative w-full h-full bg-gradient-to-br from-[#1c1538] via-[#101432] to-[#0a0d24] rounded-[22px] border border-amber-300/30 overflow-hidden flex flex-col items-center justify-center p-6 text-center shadow-inner">
                {/* Envelope Flap Lines SVG */}
                <svg className="absolute inset-0 w-full h-full pointer-events-none" viewBox="0 0 384 256" preserveAspectRatio="none">
                  {/* Flap fold */}
                  <polygon points="0,0 192,130 384,0" fill="rgba(84, 38, 168, 0.25)" stroke="rgba(255, 216, 138, 0.4)" strokeWidth="1.2" />
                  {/* Bottom fold */}
                  <polygon points="0,256 192,130 384,256" fill="transparent" stroke="rgba(255, 216, 138, 0.2)" strokeWidth="1" />
                </svg>

                {/* Golden Wax Seal */}
                <div className="relative z-10 w-16 h-16 sm:w-20 sm:h-20 rounded-full bg-gradient-to-tr from-amber-500 via-yellow-300 to-amber-600 p-0.5 shadow-glow-gold flex items-center justify-center group-hover:scale-110 transition-transform duration-300">
                  <div className="w-full h-full bg-gradient-to-br from-amber-600 to-yellow-700 rounded-full flex flex-col items-center justify-center border border-amber-300/50">
                    <Heart size={20} className="text-white fill-white animate-pulse" />
                    <span className="text-[9px] font-serif font-bold text-amber-100 tracking-wider uppercase mt-0.5">
                      Sayali
                    </span>
                  </div>
                </div>

                {/* Subtext on envelope */}
                <div className="relative z-10 mt-4">
                  <p className="text-xs uppercase tracking-widest text-cosmic-gold font-serif">
                    Private & Cherished
                  </p>
                  <p className="text-[11px] text-purple-200/70 mt-0.5">
                    Click to break the golden seal
                  </p>
                </div>
              </div>
            </div>

            <p className="mt-8 text-xs sm:text-sm text-purple-300/80 flex items-center gap-1.5">
              <Sparkles size={14} className="text-cosmic-pink" />
              <span>Tap the golden seal to open your birthday letter</span>
            </p>
          </div>
        )}

        {/* Unfolded & Revealed Love Letter */}
        {isOpen && (
          <div className="relative w-full max-w-3xl mx-auto animate-in fade-in zoom-in-95 duration-700">
            {/* Golden Parchment Letter Container */}
            <div className="relative rounded-3xl p-1 bg-gradient-to-tr from-amber-300/70 via-rose-300/60 to-purple-400/60 shadow-[0_0_70px_rgba(255,216,138,0.35)]">
              <div className="relative bg-gradient-to-b from-[#FFFDF7] via-[#FFF9EE] to-[#FFF3DF] text-[#2B1B17] rounded-[22px] p-6 sm:p-12 md:p-16 shadow-2xl overflow-hidden">
                
                {/* Watermark Crest Background */}
                <div className="absolute inset-0 flex items-center justify-center pointer-events-none opacity-5">
                  <Heart size={380} className="text-[#845217]" />
                </div>

                {/* Header Controls: Replay / Close */}
                <div className="flex items-center justify-between pb-6 mb-8 border-b border-amber-900/15">
                  <div className="flex items-center gap-2 text-amber-900/70 text-xs font-serif italic">
                    <Feather size={16} className="text-amber-700" />
                    <span>Penned with Infinite Love</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <button
                      onClick={handleReplay}
                      className="flex items-center gap-1 px-3 py-1.5 rounded-full text-xs font-medium text-amber-900 bg-amber-200/60 hover:bg-amber-300 border border-amber-800/20 transition-all hover:scale-105 active:scale-95"
                      title="Re-seal Envelope"
                    >
                      <RotateCcw size={12} />
                      <span>Re-seal</span>
                    </button>
                    <button
                      onClick={() => setIsOpen(false)}
                      className="p-1.5 rounded-full text-amber-900 hover:bg-amber-200/60 transition-colors"
                      aria-label="Close Letter"
                    >
                      <X size={16} />
                    </button>
                  </div>
                </div>

                {/* Letter Body Content */}
                <div className="space-y-6">
                  {/* Salutation */}
                  <h2 className="font-serif text-2xl sm:text-3xl font-bold text-amber-950 tracking-wide">
                    {siteConfig.loveLetter.salutation}
                  </h2>

                  {/* Paragraphs */}
                  {siteConfig.loveLetter.paragraphs.map((p, idx) => (
                    <p 
                      key={idx} 
                      className="font-serif text-base sm:text-lg text-amber-950/90 leading-relaxed sm:leading-loose font-normal"
                    >
                      {p}
                    </p>
                  ))}

                  {/* Closing & Handwritten Style Signature */}
                  <div className="pt-8 border-t border-amber-900/15 mt-8 flex flex-col items-end">
                    <p className="font-serif text-sm sm:text-base text-amber-900 italic mb-1">
                      {siteConfig.loveLetter.closing}
                    </p>
                    <p className="font-handwriting text-3xl sm:text-4xl text-rose-800 font-bold tracking-wide">
                      {siteConfig.loveLetter.signature}
                    </p>
                  </div>
                </div>

              </div>
            </div>

            {/* Next Chapter Portal Card */}
            <div className="mt-8 text-center flex flex-col sm:flex-row items-center justify-center gap-4">
              <button
                onClick={handleReplay}
                className="px-5 py-2.5 rounded-full text-xs bg-cosmic-navy/80 hover:bg-cosmic-purple/50 border border-cosmic-violet/40 text-purple-200 transition-all flex items-center gap-1.5"
              >
                <RotateCcw size={13} />
                <span>Re-read from beginning</span>
              </button>

              <Link
                to="/gifts"
                className="px-6 py-2.5 rounded-full bg-gradient-to-r from-amber-400 via-pink-500 to-purple-600 text-white font-semibold text-xs shadow-glow-gold hover:scale-105 active:scale-95 transition-all flex items-center gap-2"
              >
                <span>Step Into The Surprise Gift Room</span>
                <ArrowRight size={14} />
              </Link>
            </div>
          </div>
        )}
      </div>

    </div>
  );
};
