import React from 'react';

interface FairyLightsProps {
  className?: string;
  bulbCount?: number;
  curve?: 'top' | 'arch' | 'gentle';
}

export const FairyLights: React.FC<FairyLightsProps> = ({
  className = '',
  bulbCount = 14,
  curve = 'gentle'
}) => {
  const bulbs = Array.from({ length: bulbCount });

  return (
    <div className={`relative w-full overflow-hidden pointer-events-none select-none py-2 z-10 ${className}`} aria-hidden="true">
      {/* Curved SVG string line */}
      <svg className="w-full h-12 absolute top-0 left-0" preserveAspectRatio="none" viewBox="0 0 1000 50">
        <path
          d={
            curve === 'arch'
              ? 'M 0 10 Q 500 50 1000 10'
              : 'M 0 15 Q 250 35 500 20 T 1000 15'
          }
          fill="transparent"
          stroke="rgba(255, 216, 138, 0.28)"
          strokeWidth="1.2"
          strokeDasharray="4 2"
        />
      </svg>

      {/* Hanging fairy light bulbs */}
      <div className="relative flex justify-between items-start max-w-7xl mx-auto px-4 pt-1">
        {bulbs.map((_, i) => {
          const isGold = i % 2 === 0;
          const isPink = i % 3 === 0;
          const delay = (i * 0.25).toFixed(2);
          const duration = (2.2 + (i % 3) * 0.6).toFixed(1);

          return (
            <div
              key={i}
              className="flex flex-col items-center animate-sway"
              style={{
                animationDelay: `${delay}s`,
                animationDuration: `${3.5 + (i % 2) * 1}s`
              }}
            >
              {/* Wire drop */}
              <div
                className="w-[1px] bg-champagne-gold/30"
                style={{ height: `${8 + Math.sin(i) * 6 + 6}px` }}
              />

              {/* Tiny glowing bulb */}
              <div
                className={`w-2.5 h-3.5 rounded-full relative transition-all duration-700 animate-twinkle ${
                  isPink
                    ? 'bg-rose-300 shadow-[0_0_12px_rgba(255,130,178,0.9)]'
                    : isGold
                    ? 'bg-amber-200 shadow-[0_0_14px_rgba(255,216,138,0.95)]'
                    : 'bg-purple-200 shadow-[0_0_12px_rgba(165,107,255,0.9)]'
                }`}
                style={{
                  animationDelay: `${delay}s`,
                  animationDuration: `${duration}s`
                }}
              >
                {/* Center hot spot */}
                <div className="absolute inset-0.5 rounded-full bg-white opacity-80" />
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};
