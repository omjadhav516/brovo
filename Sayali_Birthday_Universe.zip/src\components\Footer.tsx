import React from 'react';
import { Link } from 'react-router-dom';
import { Heart, Sparkles, ArrowUp } from 'lucide-react';
import { siteConfig } from '../data/siteConfig';

export const Footer: React.FC = () => {
  const scrollToTop = () => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <footer className="relative mt-20 border-t border-cosmic-violet/20 bg-cosmic-black/80 backdrop-blur-md pt-12 pb-8 z-20">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 items-center pb-8 border-b border-purple-900/30">
          {/* Brand Info */}
          <div className="text-center md:text-left">
            <h3 className="font-serif text-xl font-bold text-gradient-gold">
              {siteConfig.title}
            </h3>
            <p className="text-xs text-purple-300/70 mt-1 max-w-sm">
              An infinite galaxy created with all my love for Sayali's Birthday. Every star shines for you.
            </p>
          </div>

          {/* Quick Route Links */}
          <div className="flex flex-wrap justify-center gap-4 text-xs text-purple-200/80">
            <Link to="/" className="hover:text-cosmic-pink transition-colors">Home</Link>
            <Link to="/story" className="hover:text-cosmic-pink transition-colors">Our Story</Link>
            <Link to="/gallery" className="hover:text-cosmic-pink transition-colors">Memory Galaxy</Link>
            <Link to="/letter" className="hover:text-cosmic-pink transition-colors">Love Letter</Link>
            <Link to="/gifts" className="hover:text-cosmic-pink transition-colors">Gifts</Link>
            <Link to="/moments" className="hover:text-cosmic-pink transition-colors">Slideshow</Link>
            <Link to="/finale" className="hover:text-cosmic-pink transition-colors font-medium text-cosmic-gold">Finale ✨</Link>
          </div>

          {/* Back to top button */}
          <div className="flex justify-center md:justify-end">
            <button
              onClick={scrollToTop}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-full text-xs bg-cosmic-navy/80 hover:bg-cosmic-purple/40 border border-cosmic-violet/30 text-purple-200 transition-all hover:scale-105 active:scale-95"
            >
              <span>Back to Top</span>
              <ArrowUp size={13} />
            </button>
          </div>
        </div>

        {/* Bottom signature */}
        <div className="pt-6 flex flex-col sm:flex-row items-center justify-between text-xs text-purple-300/60 gap-3 text-center sm:text-left">
          <p className="flex items-center justify-center gap-1">
            <span>Crafted with endless devotion for</span>
            <span className="text-cosmic-pink font-semibold">Sayali</span>
            <Heart size={12} className="text-cosmic-pink fill-cosmic-pink inline" />
          </p>
          <p className="flex items-center justify-center gap-1">
            <Sparkles size={11} className="text-cosmic-gold" />
            <span>Forever your favorite place in the stars</span>
          </p>
        </div>
      </div>
    </footer>
  );
};
