import React, { useEffect } from 'react';
import { X, ChevronLeft, ChevronRight, Calendar, Sparkles } from 'lucide-react';
import { MemoryItem } from '../data/memories';

interface LightboxProps {
  items: MemoryItem[];
  currentIndex: number;
  isOpen: boolean;
  onClose: () => void;
  onPrev: () => void;
  onNext: () => void;
}

export const Lightbox: React.FC<LightboxProps> = ({
  items,
  currentIndex,
  isOpen,
  onClose,
  onPrev,
  onNext,
}) => {
  useEffect(() => {
    if (!isOpen) return;

    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') onClose();
      if (e.key === 'ArrowLeft') onPrev();
      if (e.key === 'ArrowRight') onNext();
    };

    window.addEventListener('keydown', handleKeyDown);
    document.body.style.overflow = 'hidden';

    return () => {
      window.removeEventListener('keydown', handleKeyDown);
      document.body.style.overflow = 'unset';
    };
  }, [isOpen, onClose, onPrev, onNext]);

  if (!isOpen || items.length === 0) return null;

  const currentItem = items[currentIndex];

  return (
    <div 
      className="fixed inset-0 z-50 flex items-center justify-center bg-cosmic-black/95 backdrop-blur-2xl p-4 sm:p-6"
      role="dialog"
      aria-modal="true"
      aria-label="Photo Lightbox"
    >
      {/* Close button */}
      <button
        onClick={onClose}
        aria-label="Close photo viewer"
        className="absolute top-4 right-4 z-50 p-2.5 rounded-full bg-cosmic-navy/80 border border-cosmic-violet/40 text-purple-200 hover:text-white hover:bg-cosmic-purple/50 transition-all hover:scale-105 active:scale-95"
      >
        <X size={22} />
      </button>

      {/* Navigation - Previous */}
      <button
        onClick={onPrev}
        aria-label="Previous photograph"
        className="absolute left-3 sm:left-6 z-50 p-3 rounded-full bg-cosmic-navy/80 border border-cosmic-violet/40 text-purple-200 hover:text-white hover:bg-cosmic-purple/50 transition-all hover:scale-110 active:scale-90"
      >
        <ChevronLeft size={24} />
      </button>

      {/* Navigation - Next */}
      <button
        onClick={onNext}
        aria-label="Next photograph"
        className="absolute right-3 sm:right-6 z-50 p-3 rounded-full bg-cosmic-navy/80 border border-cosmic-violet/40 text-purple-200 hover:text-white hover:bg-cosmic-purple/50 transition-all hover:scale-110 active:scale-90"
      >
        <ChevronRight size={24} />
      </button>

      {/* Main Lightbox Content */}
      <div className="relative max-w-4xl max-h-[90vh] flex flex-col items-center justify-center">
        {/* Glowing Photo Container */}
        <div className="relative rounded-2xl overflow-hidden p-1.5 bg-gradient-to-tr from-cosmic-purple via-cosmic-pink to-cosmic-gold shadow-[0_0_50px_rgba(165,107,255,0.4)]">
          <img
            src={currentItem.image}
            alt={currentItem.title}
            className="max-h-[68vh] sm:max-h-[72vh] max-w-full object-contain rounded-xl bg-cosmic-black"
          />
        </div>

        {/* Caption & Metadata Card */}
        <div className="mt-4 w-full max-w-xl text-center bg-cosmic-navy/90 border border-cosmic-violet/30 rounded-2xl p-4 backdrop-blur-xl shadow-xl">
          <div className="flex items-center justify-center gap-2 mb-1.5">
            <span className="px-2.5 py-0.5 rounded-full text-[10px] uppercase tracking-wider bg-cosmic-purple/40 text-cosmic-gold font-semibold border border-cosmic-violet/30">
              {currentItem.category}
            </span>
            {currentItem.date && (
              <span className="text-xs text-purple-300/70 flex items-center gap-1">
                <Calendar size={11} className="text-cosmic-pink" />
                {currentItem.date}
              </span>
            )}
          </div>

          <h2 className="font-serif text-lg sm:text-xl font-bold text-white mb-1">
            {currentItem.title}
          </h2>

          <p className="text-xs sm:text-sm text-purple-200/90 leading-relaxed font-light">
            {currentItem.caption}
          </p>

          {/* Index Counter */}
          <div className="mt-2 text-[11px] text-purple-400 font-mono">
            {currentIndex + 1} of {items.length}
          </div>
        </div>
      </div>
    </div>
  );
};
