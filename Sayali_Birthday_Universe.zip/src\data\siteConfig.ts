export interface SiteConfig {
  recipientName: string;
  partnerName: string;
  birthdayDate?: string; // e.g. "2026-10-27" or undefined for today celebration
  title: string;
  tagline: string;
  heroIntroLines: string[];
  heroMainGreeting: string;
  heroSupportingMessage: string;
  heroPhotograph: string;
  loveLetter: {
    salutation: string;
    paragraphs: string[];
    closing: string;
    signature: string;
  };
  finale: {
    headline: string;
    subheadline: string;
    wishPrompt: string;
    wishRevealedMessage: string;
    blessing: string;
    finalPhoto: string;
  };
  music: {
    title: string;
    artist: string;
    src?: string; // Optional local audio asset path: '/audio/romantic-universe.mp3'
    synthesizerEnabled: boolean;
  };
}

export const siteConfig: SiteConfig = {
  recipientName: "Sayali",
  partnerName: "With All My Love",
  birthdayDate: "", // empty means celebration is live today!
  title: "SAYALI — OUR UNIVERSE",
  tagline: "A cinematic love story written in the stars",
  heroIntroLines: [
    "Somewhere in this infinite universe…",
    "There is one person who makes my universe beautiful.",
    "SAYALI ❤️"
  ],
  heroMainGreeting: "Happy Birthday, My Sayali",
  heroSupportingMessage: "Out of all the stars in this endless universe, you are the one that makes my world shine.",
  heroPhotograph: "/images/memories/sayali_hero.jpg",
  loveLetter: {
    salutation: "My dearest Sayali,",
    paragraphs: [
      "Today is a celebration of you and the happiness you bring into my world. Every photograph we share holds a little piece of our story, and every memory reminds me how special our moments together are.",
      "I hope your birthday brings you happiness, laughter, beautiful surprises, and countless reasons to smile.",
      "If I could create a universe just for you, I would fill it with every color you love, every dream you wish to follow, and every little thing that makes you happy.",
      "Happy Birthday, Sayali. I hope this little universe makes you smile and reminds you how precious you are."
    ],
    closing: "With all my love,",
    signature: "Always & Forever ❤️"
  },
  finale: {
    headline: "Today, the Whole Universe Celebrates You.",
    subheadline: "Happy Birthday, Sayali! ❤️",
    wishPrompt: "Make a Wish ✨",
    wishRevealedMessage: "Your wish is carried by millions of stars across the cosmos. May every dream of yours come true!",
    blessing: "May your world always be filled with happiness, beautiful memories, and endless possibilities.",
    finalPhoto: "/images/memories/sayali_glamour.jpg"
  },
  music: {
    title: "Cosmic Serenade (Piano & Celestial Strings)",
    artist: "Universe of Love",
    src: "/audio/universe.mp3",
    synthesizerEnabled: true
  }
};
