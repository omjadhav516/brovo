export interface MemoryItem {
  id: string;
  title: string;
  image: string;
  category: 'Best Moments' | 'Beautiful Smiles' | 'Favorite Photos' | 'Funny Memories' | 'Special Days' | 'Unforgettable Moments';
  date?: string;
  caption: string;
  storySnippet?: string;
  featured?: boolean;
}

export const memoryCategories = [
  'All',
  'Best Moments',
  'Beautiful Smiles',
  'Favorite Photos',
  'Funny Memories',
  'Special Days',
  'Unforgettable Moments'
] as const;

export const memoriesData: MemoryItem[] = [
  {
    id: 'mem-1',
    title: 'The Golden Sunshine of My Life',
    image: '/images/memories/sayali_hero.jpg',
    category: 'Beautiful Smiles',
    date: 'A Cherished Golden Afternoon',
    caption: 'Your warmth outshines the brightest star in the sky. That gentle smile makes everything calm and peaceful.',
    storySnippet: 'Whenever you look at the camera with that calm tenderness, time stands still.',
    featured: true
  },
  {
    id: 'mem-2',
    title: 'Dressed in Sunshine & Joy',
    image: '/images/memories/couple_traditional.jpg',
    category: 'Special Days',
    date: 'Festive Celebration',
    caption: 'Adorned in yellow, surrounded by festive laughter and celebration. Looking at you, my heart was full.',
    storySnippet: 'One of the most joyous celebrations where your smile was brighter than all the decorations combined.',
    featured: true
  },
  {
    id: 'mem-3',
    title: 'Pure Elegance in the Evening Starlight',
    image: '/images/memories/sayali_glamour.jpg',
    category: 'Favorite Photos',
    date: 'An Unforgettable Evening',
    caption: 'You carry yourself with such effortless grace and beauty. Every star in our galaxy envies your shine.',
    storySnippet: 'Capturing your elegance and that confident sparkle in your eyes was purely magical.',
    featured: true
  },
  {
    id: 'mem-4',
    title: 'Quiet Walks Under the Forest Canopy',
    image: '/images/memories/couple_nature.jpg',
    category: 'Unforgettable Moments',
    date: 'Nature Getaway',
    caption: 'Surrounded by green leaves and fresh air, just the two of us taking on the world together.',
    storySnippet: 'Standing by your side in the serenity of nature, knowing that with you, every place is home.',
    featured: true
  },
  {
    id: 'mem-5',
    title: 'Safe in Each Other’s Arms',
    image: '/images/memories/couple_sweet.jpg',
    category: 'Best Moments',
    date: 'Everyday Romance',
    caption: 'The warmth of your laughter and the comfort of holding you close. My absolute favorite place in the universe.',
    storySnippet: 'No grand stage needed—just simple, genuine happiness and the sweetest bond.',
    featured: true
  },
  {
    id: 'mem-6',
    title: 'Playful Laughter & Spontaneous Smiles',
    image: '/images/memories/couple_sweet.jpg',
    category: 'Funny Memories',
    date: 'Spontaneous Joy',
    caption: 'The inside jokes only the two of us understand, followed by unstoppable laughter.',
    storySnippet: 'Those candid seconds right between goofy faces and pure affection.',
    featured: false
  }
];
