import React from 'react';
import { Link } from 'react-router-dom';
import { Compass, Sparkles, AlertCircle } from 'lucide-react';
import { ConstellationCanvas } from '../components/ConstellationCanvas';

export const NotFound: React.FC = () => {
  return (
    <div className="relative min-h-[calc(100vh-4rem)] flex flex-col items-center justify-center text-center px-4">
      <ConstellationCanvas dotCount={30} connectDistance={100} />

      <div className="glass-panel max-w-md p-8 sm:p-10 rounded-3xl border border-cosmic-violet/40 shadow-2xl relative z-10">
        <div className="w-16 h-16 rounded-full bg-cosmic-purple/30 border border-cosmic-violet/40 flex items-center justify-center text-cosmic-gold mx-auto mb-4 shadow-glow-violet">
          <Sparkles size={28} className="animate-spin-slow text-cosmic-pink" />
        </div>

        <h1 className="font-serif text-5xl font-extrabold text-gradient-gold mb-2">
          404
        </h1>

        <h2 className="font-serif text-xl font-bold text-white mb-3">
          Lost in the Cosmos
        </h2>

        <p className="text-xs sm:text-sm text-purple-200/80 mb-6 leading-relaxed">
          This star seems to have drifted into an uncharted galaxy. Let us guide you back to Sayali's universe.
        </p>

        <Link
          to="/"
          className="inline-flex items-center gap-2 px-6 py-3 rounded-full bg-gradient-to-r from-cosmic-purple to-cosmic-pink text-white font-semibold text-xs shadow-glow-violet hover:scale-105 active:scale-95 transition-all"
        >
          <Compass size={15} />
          <span>Return to Universe Entrance</span>
        </Link>
      </div>
    </div>
  );
};
