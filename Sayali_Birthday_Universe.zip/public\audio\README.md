# Background Soundtrack

Place your custom MP3 soundtrack in this directory with the filename:
`universe.mp3`

The website will automatically detect and play it! If no MP3 is placed here, the built-in celestial Web Audio synthesizer generates sweet ambient space piano and celesta bells automatically.
