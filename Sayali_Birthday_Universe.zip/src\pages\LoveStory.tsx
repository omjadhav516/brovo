import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { 
  Sparkles, 
  Heart, 
  Calendar, 
  ArrowRight, 
  Compass, 
  ChevronRight, 
  Star,
  Quote
} from 'lucide-react';
import { storyChapters, StoryChapter } from '../data/story';
import { PageHeader } from '../components/PageHeader';
import { FairyLights } from '../components/FairyLights';
import { ConstellationCanvas } from '../components/ConstellationCanvas';

export const LoveStory: React.FC = () => {
  const [activeChapterId, setActiveChapterId] = useState<string>(storyChapters[0].id);

  return (
    <div className="relative min-h-screen py-10 px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto">
      <ConstellationCanvas dotCount={40} connectDistance={100} />
      <FairyLights curve="gentle" bulbCount={16} />

      <PageHeader
        badge="Chapter by Chapter"
        title="Our Love Story in the Stars"
        subtitle="Every constellation in our universe marks a milestone we share. From the day our paths crossed to the infinite dreams ahead."
      />

      {/* Chapters Navigation Bar (Pill selector) */}
      <div className="flex items-center justify-start sm:justify-center gap-2 overflow-x-auto pb-4 mb-12 scrollbar-none">
        {storyChapters.map((chapter) => (
          <button
            key={chapter.id}
            onClick={() => setActiveChapterId(chapter.id)}
            className={`px-3.5 py-1.5 rounded-full text-xs whitespace-nowrap transition-all duration-300 flex items-center gap-1.5 ${
              activeChapterId === chapter.id
                ? 'bg-gradient-to-r from-cosmic-purple to-cosmic-pink text-white shadow-glow-violet/40 font-semibold border border-cosmic-pink/40'
                : 'bg-cosmic-navy/70 text-purple-300 hover:text-white border border-cosmic-violet/20 hover:border-cosmic-violet/40'
            }`}
          >
            <span className="w-4 h-4 rounded-full bg-black/40 flex items-center justify-center text-[10px] font-mono">
              {chapter.stepNumber}
            </span>
            <span>{chapter.chapterTitle}</span>
          </button>
        ))}
      </div>

      {/* Vertical Interactive Timeline */}
      <div className="relative max-w-5xl mx-auto">
        {/* Glowing Center Line */}
        <div className="absolute left-4 md:left-1/2 top-4 bottom-4 w-0.5 bg-gradient-to-b from-cosmic-gold via-cosmic-pink to-cosmic-purple transform md:-translate-x-1/2 opacity-60 shadow-[0_0_15px_rgba(255,216,138,0.5)]" />

        <div className="space-y-16 sm:space-y-24 relative">
          {storyChapters.map((chapter, index) => {
            const isEven = index % 2 === 0;
            const isSelected = activeChapterId === chapter.id;

            return (
              <div 
                key={chapter.id}
                id={chapter.id}
                className={`relative flex flex-col md:flex-row items-center gap-8 ${
                  isEven ? 'md:flex-row-reverse' : ''
                }`}
              >
                {/* Center Star Marker */}
                <div 
                  onClick={() => setActiveChapterId(chapter.id)}
                  className="absolute left-4 md:left-1/2 transform -translate-x-1/2 z-20 cursor-pointer group"
                  title={`View Chapter ${chapter.stepNumber}`}
                >
                  <div className={`w-10 h-10 rounded-full flex items-center justify-center transition-all duration-300 ${
                    isSelected
                      ? 'bg-gradient-to-tr from-cosmic-gold to-cosmic-pink scale-125 shadow-glow-gold'
                      : 'bg-cosmic-navy border-2 border-cosmic-violet/60 hover:scale-110 hover:border-cosmic-pink'
                  }`}>
                    <Star 
                      size={16} 
                      className={isSelected ? 'text-cosmic-black fill-cosmic-black' : 'text-cosmic-gold'} 
                    />
                  </div>
                  <span className="absolute -bottom-5 left-1/2 -translate-x-1/2 text-[10px] font-mono text-purple-300/70 whitespace-nowrap hidden md:block">
                    0{chapter.stepNumber}
                  </span>
                </div>

                {/* Left / Right Card: Content */}
                <div className={`w-full md:w-[calc(50%-2.5rem)] ml-12 md:ml-0 ${
                  isEven ? 'md:text-left' : 'md:text-left'
                }`}>
                  <div 
                    onClick={() => setActiveChapterId(chapter.id)}
                    className={`cursor-pointer rounded-2xl p-6 sm:p-7 transition-all duration-300 ${
                      isSelected
                        ? 'glass-panel-gold border-cosmic-gold/50 shadow-glow-gold/20 scale-[1.02]'
                        : 'glass-panel hover:border-cosmic-violet/40 hover:scale-[1.01]'
                    }`}
                  >
                    {/* Constellation & Date Header */}
                    <div className="flex flex-wrap items-center justify-between gap-2 mb-3">
                      <span className="text-xs uppercase tracking-wider text-cosmic-gold font-mono flex items-center gap-1.5">
                        <Sparkles size={11} className="text-cosmic-pink" />
                        {chapter.constellation}
                      </span>
                      <span className="text-[11px] text-purple-300/80 bg-cosmic-purple/30 px-2.5 py-0.5 rounded-full border border-cosmic-violet/30 flex items-center gap-1">
                        <Calendar size={11} className="text-cosmic-pink" />
                        {chapter.dateBadge}
                      </span>
                    </div>

                    {/* Chapter Title */}
                    <h2 className="text-2xl font-serif font-bold text-white mb-2">
                      {chapter.chapterTitle}
                    </h2>

                    {/* Caption */}
                    <p className="text-xs sm:text-sm text-cosmic-pink font-medium mb-4 italic">
                      "{chapter.caption}"
                    </p>

                    {/* Personal Message */}
                    <p className="text-sm text-purple-100/90 leading-relaxed font-light mb-4">
                      {chapter.personalMessage}
                    </p>

                    {/* Sweet Reflection Quote */}
                    <div className="mt-4 pt-3 border-t border-purple-900/40 flex items-start gap-2 text-xs text-purple-300/80">
                      <Quote size={14} className="text-cosmic-gold shrink-0 mt-0.5" />
                      <span className="font-serif italic">{chapter.reflection}</span>
                    </div>
                  </div>
                </div>

                {/* Opposite Side: Photograph with Cosmic Aura */}
                <div className="w-full md:w-[calc(50%-2.5rem)] ml-12 md:ml-0">
                  <div className="relative group rounded-2xl overflow-hidden p-1.5 bg-gradient-to-br from-cosmic-purple/40 via-cosmic-pink/30 to-cosmic-gold/30 border border-cosmic-violet/40 shadow-xl">
                    <div className="relative aspect-[16/10] sm:aspect-[16/11] overflow-hidden rounded-xl bg-cosmic-black">
                      <img
                        src={chapter.image}
                        alt={chapter.chapterTitle}
                        className="w-full h-full object-cover object-center group-hover:scale-105 transition-transform duration-700"
                      />
                      <div className="absolute inset-0 bg-gradient-to-t from-cosmic-black/70 via-transparent to-transparent" />
                      <div className="absolute bottom-3 left-3 right-3 flex items-center justify-between text-white text-xs">
                        <span className="font-serif tracking-wide text-cosmic-gold">
                          Milestone 0{chapter.stepNumber}
                        </span>
                        <span className="text-[11px] text-purple-200/80">
                          {chapter.chapterTitle}
                        </span>
                      </div>
                    </div>
                  </div>
                </div>

              </div>
            );
          })}
        </div>
      </div>

      {/* Call to Next Chapter */}
      <div className="mt-20 text-center">
        <div className="glass-panel max-w-xl mx-auto p-6 rounded-3xl border border-cosmic-violet/30 shadow-2xl">
          <Heart size={24} className="text-cosmic-pink mx-auto mb-2 animate-pulse fill-cosmic-pink" />
          <h3 className="font-serif text-xl font-bold text-white mb-2">
            The Journey Continues in Our Memory Galaxy
          </h3>
          <p className="text-xs sm:text-sm text-purple-200/80 mb-5">
            Step into the Memory Galaxy to explore all our real photographs in an interactive cosmic grid.
          </p>
          <Link
            to="/gallery"
            className="inline-flex items-center gap-2 px-6 py-3 rounded-full bg-gradient-to-r from-cosmic-purple to-cosmic-pink text-white font-semibold text-xs shadow-glow-violet hover:scale-105 active:scale-95 transition-all"
          >
            <span>Enter Memory Galaxy</span>
            <ArrowRight size={14} />
          </Link>
        </div>
      </div>
    </div>
  );
};
