import React, { useState, useEffect, useRef } from 'react';
import { Link } from 'react-router-dom';
import { 
  Play, 
  Pause, 
  ChevronLeft, 
  ChevronRight, 
  Maximize2, 
  Minimize2, 
  RotateCcw, 
  Heart, 
  Sparkles, 
  Calendar, 
  ArrowRight,
  Clock
} from 'lucide-react';
import { memoriesData } from '../data/memories';
import { PageHeader } from '../components/PageHeader';
import { FairyLights } from '../components/FairyLights';
import { ConstellationCanvas } from '../components/ConstellationCanvas';

export const SpecialMoments: React.FC = () => {
  const [currentIndex, setCurrentIndex] = useState<number>(0);
  const [isPlaying, setIsPlaying] = useState<boolean>(true);
  const [isFullscreen, setIsFullscreen] = useState<boolean>(false);
  const [duration, setDuration] = useState<number>(4500); // 4.5s
  const [isEnded, setIsEnded] = useState<boolean>(false);

  const containerRef = useRef<HTMLDivElement | null>(null);

  const photos = memoriesData;

  // Autoplay timer
  useEffect(() => {
    if (!isPlaying || isEnded) return;

    const timer = setInterval(() => {
      setCurrentIndex((prev) => {
        if (prev === photos.length - 1) {
          setIsEnded(true);
          setIsPlaying(false);
          return prev;
        }
        return prev + 1;
      });
    }, duration);

    return () => clearInterval(timer);
  }, [isPlaying, isEnded, duration, photos.length]);

  const handleNext = () => {
    setIsEnded(false);
    setCurrentIndex((prev) => (prev + 1) % photos.length);
  };

  const handlePrev = () => {
    setIsEnded(false);
    setCurrentIndex((prev) => (prev - 1 + photos.length) % photos.length);
  };

  const toggleFullscreen = () => {
    if (!document.fullscreenElement) {
      containerRef.current?.requestFullscreen().then(() => {
        setIsFullscreen(true);
      }).catch(() => {});
    } else {
      document.exitFullscreen().then(() => {
        setIsFullscreen(false);
      }).catch(() => {});
    }
  };

  const restartSlideshow = () => {
    setCurrentIndex(0);
    setIsEnded(false);
    setIsPlaying(true);
  };

  const currentPhoto = photos[currentIndex];

  return (
    <div className="relative min-h-screen py-10 px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto flex flex-col justify-between">
      <ConstellationCanvas dotCount={35} connectDistance={100} />
      <FairyLights curve="arch" bulbCount={16} />

      <PageHeader
        badge="Cinematic Presentation"
        title="Our Special Moments in Motion"
        subtitle="Sit back, breathe, and let our most treasured memories drift across the starlight one by one."
      />

      {/* Main Slideshow Frame */}
      <div 
        ref={containerRef}
        className={`relative w-full max-w-4xl mx-auto rounded-3xl overflow-hidden glass-panel p-3 sm:p-5 border border-cosmic-violet/40 shadow-[0_0_60px_rgba(165,107,255,0.25)] ${
          isFullscreen ? 'max-w-none h-screen rounded-none p-6 flex flex-col justify-between bg-cosmic-black' : ''
        }`}
      >
        {/* Slideshow Photo Screen */}
        <div className="relative aspect-[16/10] sm:aspect-[16/9] w-full rounded-2xl overflow-hidden bg-cosmic-black shadow-inner flex items-center justify-center">
          
          {/* Animated Crossfade Image */}
          <img
            key={currentPhoto.id}
            src={currentPhoto.image}
            alt={currentPhoto.title}
            className="w-full h-full object-contain sm:object-cover object-center animate-in fade-in duration-700 transition-transform duration-1000 scale-100 hover:scale-105"
          />

          {/* Vignette Overlay */}
          <div className="absolute inset-0 bg-gradient-to-t from-cosmic-black/85 via-transparent to-black/30 pointer-events-none" />

          {/* Category & Date Badge on Top Left */}
          <div className="absolute top-4 left-4 flex items-center gap-2">
            <span className="px-3 py-1 rounded-full text-[10px] font-semibold uppercase tracking-wider bg-cosmic-black/80 backdrop-blur-md text-cosmic-gold border border-cosmic-violet/30">
              {currentPhoto.category}
            </span>
            {currentPhoto.date && (
              <span className="hidden sm:flex items-center gap-1 px-3 py-1 rounded-full text-[10px] bg-cosmic-black/70 backdrop-blur-md text-purple-200 border border-white/10 font-mono">
                <Calendar size={11} className="text-cosmic-pink" />
                {currentPhoto.date}
              </span>
            )}
          </div>

          {/* Fullscreen Toggle Top Right */}
          <button
            onClick={toggleFullscreen}
            aria-label={isFullscreen ? "Exit Fullscreen" : "Enter Fullscreen"}
            className="absolute top-4 right-4 p-2.5 rounded-full bg-cosmic-black/70 hover:bg-cosmic-purple/60 backdrop-blur-md border border-white/20 text-white transition-all hover:scale-110 active:scale-95"
          >
            {isFullscreen ? <Minimize2 size={16} /> : <Maximize2 size={16} />}
          </button>

          {/* Bottom Caption Inside Slideshow */}
          <div className="absolute bottom-4 left-4 right-4 sm:bottom-6 sm:left-6 sm:right-6 text-center sm:text-left pointer-events-none">
            <h3 className="font-serif text-xl sm:text-2xl font-bold text-white drop-shadow-md">
              {currentPhoto.title}
            </h3>
            <p className="text-xs sm:text-sm text-purple-100/90 italic mt-1 font-light max-w-2xl drop-shadow">
              "{currentPhoto.caption}"
            </p>
          </div>

          {/* Ending Final Message Overlay */}
          {isEnded && (
            <div className="absolute inset-0 z-30 bg-cosmic-black/90 backdrop-blur-md flex flex-col items-center justify-center p-6 text-center animate-in fade-in duration-500">
              <Heart size={36} className="text-cosmic-pink fill-cosmic-pink animate-bounce mb-3" />
              <h3 className="font-serif text-2xl sm:text-3xl font-bold text-gradient-cosmic mb-2">
                And Our Universe Keeps Growing
              </h3>
              <p className="text-xs sm:text-sm text-purple-200/90 max-w-md mb-6 leading-relaxed">
                Every photograph here is just a single star in our infinite sky. The greatest adventures and happiest memories are still waiting for us.
              </p>
              <div className="flex items-center gap-3">
                <button
                  onClick={restartSlideshow}
                  className="px-5 py-2.5 rounded-full bg-cosmic-navy hover:bg-cosmic-purple/50 border border-cosmic-violet/40 text-purple-200 text-xs transition-all flex items-center gap-1.5"
                >
                  <RotateCcw size={13} />
                  <span>Replay Slideshow</span>
                </button>
                <Link
                  to="/finale"
                  className="px-6 py-2.5 rounded-full bg-gradient-to-r from-amber-400 to-pink-500 text-white font-semibold text-xs shadow-glow-gold hover:scale-105 active:scale-95 transition-all flex items-center gap-1.5"
                >
                  <span>Grand Birthday Finale ✨</span>
                  <ArrowRight size={14} />
                </Link>
              </div>
            </div>
          )}
        </div>

        {/* Slideshow Controls Bar */}
        <div className="mt-4 flex flex-col sm:flex-row items-center justify-between gap-4 px-2 py-1">
          {/* Progress / Step indicators */}
          <div className="flex items-center gap-1.5">
            {photos.map((_, idx) => (
              <button
                key={idx}
                onClick={() => {
                  setCurrentIndex(idx);
                  setIsEnded(false);
                }}
                className={`h-1.5 rounded-full transition-all duration-300 ${
                  currentIndex === idx
                    ? 'w-6 bg-gradient-to-r from-cosmic-gold to-cosmic-pink'
                    : 'w-2 bg-purple-900/50 hover:bg-purple-700/60'
                }`}
                aria-label={`Go to slide ${idx + 1}`}
              />
            ))}
            <span className="text-xs text-purple-400 font-mono ml-2">
              {currentIndex + 1} / {photos.length}
            </span>
          </div>

          {/* Central Playback Buttons */}
          <div className="flex items-center gap-3">
            <button
              onClick={handlePrev}
              aria-label="Previous Slide"
              className="p-2 rounded-full bg-cosmic-navy/80 border border-cosmic-violet/30 text-purple-200 hover:text-white hover:bg-cosmic-purple/40 transition-transform active:scale-90"
            >
              <ChevronLeft size={18} />
            </button>

            <button
              onClick={() => {
                if (isEnded) {
                  restartSlideshow();
                } else {
                  setIsPlaying(!isPlaying);
                }
              }}
              aria-label={isPlaying ? "Pause Slideshow" : "Play Slideshow"}
              className="w-10 h-10 rounded-full bg-gradient-to-r from-cosmic-purple to-cosmic-pink flex items-center justify-center text-white shadow-glow-violet hover:scale-105 active:scale-95 transition-all"
            >
              {isPlaying ? <Pause size={17} /> : <Play size={17} className="ml-0.5" />}
            </button>

            <button
              onClick={handleNext}
              aria-label="Next Slide"
              className="p-2 rounded-full bg-cosmic-navy/80 border border-cosmic-violet/30 text-purple-200 hover:text-white hover:bg-cosmic-purple/40 transition-transform active:scale-90"
            >
              <ChevronRight size={18} />
            </button>
          </div>

          {/* Speed configuration */}
          <div className="flex items-center gap-2 text-xs text-purple-300/80">
            <Clock size={12} className="text-cosmic-gold" />
            <span>Speed:</span>
            <select
              value={duration}
              onChange={(e) => setDuration(Number(e.target.value))}
              className="bg-cosmic-navy border border-cosmic-violet/30 rounded-lg px-2 py-1 text-xs text-purple-200 cursor-pointer focus:outline-none"
            >
              <option value={3000}>3 sec</option>
              <option value={4500}>4.5 sec</option>
              <option value={6000}>6 sec</option>
              <option value={8000}>8 sec</option>
            </select>
          </div>
        </div>
      </div>

      {/* Direct Jump to Finale */}
      <div className="mt-12 text-center">
        <Link
          to="/finale"
          className="inline-flex items-center gap-2 px-8 py-3.5 rounded-full bg-gradient-to-r from-amber-400 via-rose-500 to-purple-600 text-white font-bold text-xs sm:text-sm shadow-glow-gold hover:scale-105 active:scale-95 transition-all"
        >
          <Sparkles size={16} />
          <span>Proceed to The Grand Birthday Finale</span>
          <ArrowRight size={16} />
        </Link>
      </div>
    </div>
  );
};
