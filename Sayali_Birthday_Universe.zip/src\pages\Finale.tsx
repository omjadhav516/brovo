import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { 
  Sparkles, 
  Heart, 
  PartyPopper, 
  Flame, 
  RotateCcw, 
  Star, 
  Compass, 
  Share2, 
  Check 
} from 'lucide-react';
import { siteConfig } from '../data/siteConfig';
import { launchConfetti } from '../utils/confetti';
import { FairyLights } from '../components/FairyLights';
import { ConstellationCanvas } from '../components/ConstellationCanvas';

export const Finale: React.FC = () => {
  const [wishMade, setWishMade] = useState<boolean>(false);
  const [candlesBlown, setCandlesBlown] = useState<boolean>(false);
  const [copied, setCopied] = useState<boolean>(false);

  const handleMakeWish = () => {
    setCandlesBlown(true);
    setWishMade(true);
    launchConfetti();
    setTimeout(() => {
      launchConfetti();
    }, 1200);
  };

  const handleShare = () => {
    navigator.clipboard?.writeText(window.location.origin);
    setCopied(true);
    setTimeout(() => setCopied(false), 2500);
  };

  const handleRelight = () => {
    setCandlesBlown(false);
    setWishMade(false);
  };

  return (
    <div className="relative min-h-screen py-10 px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto flex flex-col justify-between overflow-hidden">
      <ConstellationCanvas dotCount={45} connectDistance={120} />
      <FairyLights curve="arch" bulbCount={20} />

      {/* Floating Rose Petals Layer */}
      <div className="fixed inset-0 pointer-events-none z-10 overflow-hidden" aria-hidden="true">
        {Array.from({ length: 15 }).map((_, i) => (
          <div
            key={i}
            className="absolute rounded-full bg-gradient-to-tr from-rose-500/40 to-pink-300/30 blur-[1px]"
            style={{
              width: `${12 + (i % 4) * 5}px`,
              height: `${18 + (i % 3) * 6}px`,
              left: `${(i * 7) % 100}%`,
              animation: `petal-fall ${9 + (i % 5) * 2}s linear infinite`,
              animationDelay: `${(i * 1.3) % 8}s`,
            }}
          />
        ))}
      </div>

      {/* Top Banner Celebration */}
      <div className="text-center relative z-20 mb-8 sm:mb-12">
        <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full text-xs font-semibold tracking-widest uppercase bg-gradient-to-r from-amber-500/30 via-pink-500/30 to-purple-500/30 border border-cosmic-gold/40 text-cosmic-gold shadow-glow-gold mb-4">
          <Sparkles size={14} className="text-cosmic-pink animate-spin-slow" />
          <span>The Grand Cosmic Finale</span>
          <Heart size={13} className="text-cosmic-pink fill-cosmic-pink" />
        </div>

        {/* Revealed Lines */}
        <h2 className="text-2xl sm:text-3xl md:text-4xl font-serif text-purple-200/90 font-light tracking-wide mb-2">
          {siteConfig.finale.headline}
        </h2>

        <h1 className="text-4xl sm:text-6xl md:text-7xl font-serif font-extrabold text-gradient-rose tracking-tight mb-4 drop-shadow-[0_0_35px_rgba(255,130,178,0.5)]">
          {siteConfig.finale.subheadline}
        </h1>

        <p className="text-sm sm:text-base text-purple-200/80 max-w-xl mx-auto font-light">
          Out of 100 billion galaxies, my heart chose you. Today, all the stars join together in your honor.
        </p>
      </div>

      {/* Center Interactive Birthday Cake & Celestial Planet Scene */}
      <div className="relative z-20 flex-1 flex flex-col items-center justify-center my-6">
        
        {/* Luminous Central Planet & Aura */}
        <div className="relative flex items-center justify-center">
          {/* Heart-shaped galaxy aura glow */}
          <div className="absolute w-72 h-72 sm:w-96 sm:h-96 rounded-full bg-gradient-to-tr from-cosmic-purple/30 via-cosmic-pink/25 to-amber-300/20 blur-[90px] animate-pulse-slow pointer-events-none" />

          {/* Interactive Birthday Cake Illustration */}
          <div className="relative flex flex-col items-center">
            
            {/* Glowing Candles */}
            <div className="flex items-center gap-4 sm:gap-6 mb-1 z-30">
              {[0, 1, 2].map((idx) => (
                <div key={idx} className="flex flex-col items-center">
                  {/* Candle Flame with Glow */}
                  {!candlesBlown ? (
                    <div className="relative flex items-center justify-center animate-bounce" style={{ animationDuration: `${1.2 + idx * 0.2}s` }}>
                      <div className="w-4 h-6 rounded-full bg-gradient-to-t from-amber-500 via-yellow-300 to-white shadow-[0_0_18px_rgba(255,216,138,1)]" />
                      <Flame size={18} className="absolute text-amber-200 fill-amber-300 opacity-90" />
                    </div>
                  ) : (
                    <div className="h-6 flex items-center justify-center">
                      <span className="text-[10px] text-purple-300/60 font-mono animate-pulse">✨ wish</span>
                    </div>
                  )}
                  {/* Candle Stick */}
                  <div className="w-2.5 h-9 rounded-t bg-gradient-to-b from-rose-300 via-pink-400 to-rose-500 shadow-sm border-x border-white/20" />
                </div>
              ))}
            </div>

            {/* Cake Tiers (Cosmic Glass Layered Cake) */}
            <div className="relative flex flex-col items-center">
              {/* Top Tier */}
              <div className="w-44 sm:w-56 h-14 rounded-t-2xl bg-gradient-to-r from-purple-900/90 via-pink-800/80 to-purple-900/90 border border-cosmic-pink/50 shadow-lg flex items-center justify-center relative overflow-hidden">
                <div className="absolute inset-x-0 top-0 h-2 bg-gradient-to-r from-amber-300 via-pink-300 to-amber-300 opacity-80" />
                <span className="text-xs font-serif text-cosmic-gold tracking-widest uppercase font-bold">
                  Sayali
                </span>
              </div>

              {/* Bottom Tier */}
              <div className="w-64 sm:w-80 h-20 rounded-b-3xl bg-gradient-to-r from-cosmic-navy via-purple-950 to-cosmic-navy border-2 border-cosmic-gold/40 shadow-2xl flex items-center justify-around px-6 relative overflow-hidden">
                <div className="absolute inset-x-0 top-0 h-2.5 bg-gradient-to-r from-pink-400 via-rose-300 to-pink-400" />
                
                {/* Cake decorations: little stars */}
                {Array.from({ length: 5 }).map((_, i) => (
                  <Star key={i} size={14} className="text-cosmic-gold fill-cosmic-gold/70 animate-twinkle" style={{ animationDelay: `${i * 0.4}s` }} />
                ))}
              </div>

              {/* Golden Platter */}
              <div className="w-72 sm:w-96 h-4 rounded-full bg-gradient-to-r from-transparent via-amber-400 to-transparent opacity-80 blur-[1px] mt-1 shadow-glow-gold" />
            </div>

          </div>
        </div>

        {/* Wish Button */}
        <div className="mt-10 text-center z-30">
          {!wishMade ? (
            <button
              onClick={handleMakeWish}
              className="group px-8 sm:px-10 py-4 rounded-full bg-gradient-to-r from-amber-400 via-rose-500 to-purple-600 text-white font-bold text-base sm:text-lg shadow-[0_0_40px_rgba(255,216,138,0.5)] hover:shadow-[0_0_60px_rgba(255,130,178,0.8)] transition-all duration-300 hover:scale-108 active:scale-95 flex items-center gap-3 mx-auto"
            >
              <Sparkles size={20} className="animate-spin-slow text-amber-200" />
              <span>{siteConfig.finale.wishPrompt}</span>
              <PartyPopper size={20} className="group-hover:rotate-12 transition-transform" />
            </button>
          ) : (
            <div className="flex flex-col items-center animate-in fade-in zoom-in-95 duration-500">
              <div className="px-6 py-2.5 rounded-full bg-emerald-500/20 border border-emerald-400/40 text-emerald-300 text-xs sm:text-sm font-semibold flex items-center gap-2 shadow-lg mb-3">
                <Check size={16} />
                <span>Your wish has been whispered to the cosmos!</span>
              </div>
              <button
                onClick={handleRelight}
                className="text-xs text-purple-300 hover:text-white flex items-center gap-1.5 transition-colors"
              >
                <RotateCcw size={12} />
                <span>Light the candles again</span>
              </button>
            </div>
          )}
        </div>

        {/* Revealed Final Photograph & Blessing (Appears prominently after wish or directly visible) */}
        <div className={`mt-12 w-full max-w-2xl mx-auto glass-panel p-6 sm:p-8 rounded-3xl border border-cosmic-gold/40 shadow-2xl text-center transition-all duration-700 ${
          wishMade ? 'scale-105 shadow-[0_0_70px_rgba(255,216,138,0.35)]' : ''
        }`}>
          {/* Final Photo in Glowing Circular / Editorial Frame */}
          <div className="relative w-36 h-36 sm:w-44 sm:h-44 mx-auto rounded-full p-1 bg-gradient-to-tr from-cosmic-gold via-cosmic-pink to-cosmic-purple shadow-glow-gold mb-6">
            <img
              src={siteConfig.finale.finalPhoto}
              alt="Sayali - Happy Birthday"
              className="w-full h-full object-cover object-center rounded-full bg-cosmic-black"
            />
            <div className="absolute -bottom-1 -right-1 w-9 h-9 rounded-full bg-cosmic-pink text-white flex items-center justify-center shadow-lg">
              <Heart size={16} className="fill-white" />
            </div>
          </div>

          {/* Final Blessing */}
          <blockquote className="font-serif text-lg sm:text-xl text-purple-100 italic leading-relaxed mb-4">
            "{siteConfig.finale.blessing}"
          </blockquote>

          <p className="font-handwriting text-3xl sm:text-4xl text-gradient-rose font-bold">
            Forever Yours ❤️
          </p>
        </div>

      </div>

      {/* Navigation / Replay universe shortcuts */}
      <div className="relative z-20 mt-12 pt-6 border-t border-purple-900/30 flex flex-wrap items-center justify-center gap-4 text-center">
        <Link
          to="/"
          className="px-6 py-2.5 rounded-full bg-cosmic-navy/80 hover:bg-cosmic-purple/50 border border-cosmic-violet/40 text-purple-200 text-xs transition-all flex items-center gap-1.5"
        >
          <Compass size={14} />
          <span>Return to Universe Entrance</span>
        </Link>

        <button
          onClick={handleShare}
          className="px-6 py-2.5 rounded-full bg-cosmic-purple/40 hover:bg-cosmic-purple/60 border border-cosmic-violet/40 text-cosmic-gold text-xs transition-all flex items-center gap-1.5"
        >
          <Share2 size={13} />
          <span>{copied ? 'Link Copied to Clipboard!' : 'Share This Universe'}</span>
        </button>
      </div>
    </div>
  );
};
